import SwiftUI

nonisolated enum AppCurrency: String, CaseIterable, Sendable, Identifiable {
    case eur = "EUR"
    case usd = "USD"
    case gbp = "GBP"
    case chf = "CHF"
    case all = "ALL"

    nonisolated var id: String { rawValue }

    var displayName: String {
        switch self {
        case .eur: return "Euro (EUR)"
        case .usd: return "US Dollar (USD)"
        case .gbp: return "British Pound (GBP)"
        case .chf: return "Swiss Franc (CHF)"
        case .all: return "Albanian Lek (ALL)"
        }
    }

    var symbol: String {
        switch self {
        case .eur: return "\u{20AC}"
        case .usd: return "$"
        case .gbp: return "\u{00A3}"
        case .chf: return "CHF"
        case .all: return "L"
        }
    }
}

@Observable
final class CurrencyManager {
    var selected: AppCurrency {
        didSet {
            UserDefaults.standard.set(selected.rawValue, forKey: "selectedCurrency")
        }
    }

    var currencyCode: String { selected.rawValue }

    init() {
        let saved = UserDefaults.standard.string(forKey: "selectedCurrency") ?? "EUR"
        self.selected = AppCurrency(rawValue: saved) ?? .eur
    }
}
