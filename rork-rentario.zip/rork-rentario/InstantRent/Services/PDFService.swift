import Foundation
import UIKit
import PDFKit

struct PDFService {
    static func generateContractPDF(
        rental: Rental,
        resolvedContent: String,
        signatureImage: UIImage?
    ) -> URL? {
        let pageWidth: CGFloat = 612
        let pageHeight: CGFloat = 792
        let margin: CGFloat = 50
        let contentWidth = pageWidth - margin * 2

        let pdfRenderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight))

        let data = pdfRenderer.pdfData { context in
            context.beginPage()

            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 4

            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 11),
                .foregroundColor: UIColor.black,
                .paragraphStyle: paragraphStyle
            ]

            let titleAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: 16),
                .foregroundColor: UIColor.black
            ]

            let lines = resolvedContent.components(separatedBy: "\n")
            var yPosition: CGFloat = margin

            for line in lines {
                if yPosition > pageHeight - margin - 100 {
                    context.beginPage()
                    yPosition = margin
                }

                let attrs = line.hasPrefix("RENTAL AGREEMENT") || line.hasPrefix("RENTER INFORMATION") ||
                    line.hasPrefix("VEHICLE INFORMATION") || line.hasPrefix("RENTAL DETAILS") ||
                    line.hasPrefix("TERMS AND CONDITIONS") || line.hasPrefix("SIGNATURES") ||
                    line.hasPrefix("MIETVERTRAG") || line.hasPrefix("MIETERINFORMATIONEN") ||
                    line.hasPrefix("FAHRZEUGINFORMATIONEN") || line.hasPrefix("MIETDETAILS") ||
                    line.hasPrefix("GESCHÄFTSBEDINGUNGEN") || line.hasPrefix("UNTERSCHRIFTEN")
                    ? titleAttributes : attributes

                let textRect = CGRect(x: margin, y: yPosition, width: contentWidth, height: 1000)
                let text = NSAttributedString(string: line, attributes: attrs)
                let boundingRect = text.boundingRect(with: CGSize(width: contentWidth, height: .greatestFiniteMagnitude), options: [.usesLineFragmentOrigin], context: nil)
                text.draw(in: textRect)
                yPosition += boundingRect.height + 4
            }

            if let signature = signatureImage {
                if yPosition > pageHeight - margin - 120 {
                    context.beginPage()
                    yPosition = margin
                }

                yPosition += 20
                let sigLabel = NSAttributedString(string: "Signature:", attributes: attributes)
                sigLabel.draw(at: CGPoint(x: margin, y: yPosition))
                yPosition += 20

                let sigHeight: CGFloat = 80
                let sigWidth = sigHeight * (signature.size.width / signature.size.height)
                let sigRect = CGRect(x: margin, y: yPosition, width: min(sigWidth, contentWidth), height: sigHeight)
                signature.draw(in: sigRect)
            }
        }

        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let contractsDir = documentsURL.appendingPathComponent("contracts")
        try? FileManager.default.createDirectory(at: contractsDir, withIntermediateDirectories: true)

        let fileName = "contract_\(rental.id.uuidString).pdf"
        let fileURL = contractsDir.appendingPathComponent(fileName)

        do {
            try data.write(to: fileURL)
            return fileURL
        } catch {
            return nil
        }
    }

    static func resolveTemplate(_ template: String, rental: Rental, currencyCode: String = "EUR") -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium

        var content = template

        content = content.replacingOccurrences(of: "{{date}}", with: dateFormatter.string(from: Date()))
        content = content.replacingOccurrences(of: "{{client_name}}", with: rental.client?.fullName ?? "-")
        content = content.replacingOccurrences(of: "{{client_phone}}", with: rental.client?.phone ?? "-")
        content = content.replacingOccurrences(of: "{{client_email}}", with: rental.client?.email ?? "-")
        content = content.replacingOccurrences(of: "{{car_make}}", with: rental.car?.make ?? "-")
        content = content.replacingOccurrences(of: "{{car_model}}", with: rental.car?.model ?? "-")
        content = content.replacingOccurrences(of: "{{car_year}}", with: "\(rental.car?.year ?? 0)")
        content = content.replacingOccurrences(of: "{{car_license_plate}}", with: rental.car?.licensePlate ?? "-")
        content = content.replacingOccurrences(of: "{{car_color}}", with: rental.car?.carColor.displayName ?? "-")
        content = content.replacingOccurrences(of: "{{car_transmission}}", with: rental.car?.transmission.rawValue.capitalized ?? "-")
        content = content.replacingOccurrences(of: "{{car_fuel_type}}", with: rental.car?.fuelType.rawValue.capitalized ?? "-")
        content = content.replacingOccurrences(of: "{{km_at_pickup}}", with: "\(rental.kmAtPickup)")
        content = content.replacingOccurrences(of: "{{pickup_date}}", with: dateFormatter.string(from: rental.pickupDate))
        content = content.replacingOccurrences(of: "{{return_date}}", with: dateFormatter.string(from: rental.returnDate))
        content = content.replacingOccurrences(of: "{{number_of_days}}", with: "\(rental.numberOfDays)")
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = currencyCode
        let formatAmount: (Double) -> String = { amount in
            formatter.string(from: NSNumber(value: amount)) ?? String(format: "%.2f", amount)
        }

        content = content.replacingOccurrences(of: "{{daily_rate}}", with: formatAmount(rental.dailyRate))

        let extrasList = rental.extras.map { "\($0.name): \(formatAmount($0.pricePerDay))\($0.isFlat ? " (flat)" : "/day")" }.joined(separator: ", ")
        content = content.replacingOccurrences(of: "{{extras_list}}", with: extrasList.isEmpty ? "-" : extrasList)

        var discountText = "-"
        if rental.discountType == "percentage" {
            discountText = "\(String(format: "%.0f", rental.discountValue))%"
        } else if rental.discountType == "fixed" {
            discountText = formatAmount(rental.discountValue)
        }
        content = content.replacingOccurrences(of: "{{discount}}", with: discountText)
        content = content.replacingOccurrences(of: "{{total_price}}", with: formatAmount(rental.totalPrice))

        return content
    }
}
