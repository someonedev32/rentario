import Foundation

struct PricingEngine {
    static func calculateTotal(
        dailyRate: Double,
        numberOfDays: Int,
        extras: [RentalExtra],
        discountType: String,
        discountValue: Double
    ) -> Double {
        let basePrice = dailyRate * Double(numberOfDays)

        var extrasTotal: Double = 0
        for extra in extras {
            if extra.isFlat {
                extrasTotal += extra.pricePerDay
            } else {
                extrasTotal += extra.pricePerDay * Double(numberOfDays)
            }
        }

        let subtotal = basePrice + extrasTotal

        var discount: Double = 0
        switch discountType {
        case "percentage":
            discount = subtotal * (discountValue / 100.0)
        case "fixed":
            discount = discountValue
        default:
            break
        }

        return max(subtotal - discount, 0)
    }

    static func extrasTotal(extras: [RentalExtra], numberOfDays: Int) -> Double {
        extras.reduce(0) { sum, extra in
            sum + (extra.isFlat ? extra.pricePerDay : extra.pricePerDay * Double(numberOfDays))
        }
    }
}
