import Foundation
import UIKit

struct ImageStorageService {
    private static var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static func saveImage(_ image: UIImage, folder: String, fileName: String? = nil) -> String? {
        let folderURL = documentsDirectory.appendingPathComponent(folder)
        try? FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true)

        let name = fileName ?? UUID().uuidString
        let fileURL = folderURL.appendingPathComponent("\(name).jpg")

        guard let data = image.jpegData(compressionQuality: 0.8) else { return nil }

        do {
            try data.write(to: fileURL)
            return "\(folder)/\(name).jpg"
        } catch {
            return nil
        }
    }

    static func loadImage(relativePath: String) -> UIImage? {
        let url = documentsDirectory.appendingPathComponent(relativePath)
        guard let data = try? Data(contentsOf: url) else { return nil }
        return UIImage(data: data)
    }

    static func deleteImage(relativePath: String) {
        let url = documentsDirectory.appendingPathComponent(relativePath)
        try? FileManager.default.removeItem(at: url)
    }

    static func saveSignature(_ image: UIImage, rentalId: UUID) -> String? {
        return saveImage(image, folder: "signatures", fileName: rentalId.uuidString)
    }
}
