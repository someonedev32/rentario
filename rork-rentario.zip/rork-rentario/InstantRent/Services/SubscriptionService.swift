import Foundation
import UIKit
import StoreKit
import RevenueCat

nonisolated enum ProState: String, Sendable {
    case active
    case expired
    case inactive
}

@Observable
@MainActor
class SubscriptionService {
    var offerings: Offerings?
    var isLoading: Bool = false
    var isPurchasing: Bool = false
    var errorMessage: String?
    var showError: Bool = false
    var proState: ProState = .inactive

    var isProUser: Bool { proState == .active }

    private let entitlementID = "pro"
    private let cachedStateKey = "cached_pro_state"

    var currentOffering: Offering? {
        offerings?.current
    }

    var availablePackages: [Package] {
        currentOffering?.availablePackages ?? []
    }

    var sortedPackages: [Package] {
        availablePackages.sorted { a, b in
            totalMonths(for: a) > totalMonths(for: b)
        }
    }

    init() {
        let cached = UserDefaults.standard.string(forKey: cachedStateKey) ?? "inactive"
        proState = ProState(rawValue: cached) ?? .inactive
    }

    func initialize() {
        Task { await listenForUpdates() }
        Task { await refreshEntitlements() }
    }

    private func listenForUpdates() async {
        for await info in Purchases.shared.customerInfoStream {
            updateFromCustomerInfo(info)
        }
    }

    func checkEntitlement() async {
        await refreshEntitlements()
    }

    func refreshEntitlements() async {
        do {
            let customerInfo = try await Purchases.shared.customerInfo()
            updateFromCustomerInfo(customerInfo)
        } catch {
            print("[RC] refreshEntitlements error: \(error)")
        }
    }

    func fetchOfferings() async {
        isLoading = true
        defer { isLoading = false }

        do {
            let result = try await Purchases.shared.offerings()
            offerings = result
        } catch {
            errorMessage = error.localizedDescription
            showError = true
        }
    }

    func purchase(_ package: Package) async {
        isPurchasing = true
        defer { isPurchasing = false }
        do {
            let result = try await Purchases.shared.purchase(package: package)
            if !result.userCancelled {
                updateFromCustomerInfo(result.customerInfo)
            }
        } catch ErrorCode.purchaseCancelledError {
        } catch ErrorCode.paymentPendingError {
        } catch {
            errorMessage = error.localizedDescription
            showError = true
        }
    }

    func restorePurchases() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let customerInfo = try await Purchases.shared.restorePurchases()
            updateFromCustomerInfo(customerInfo)
            if !isProUser {
                errorMessage = String(localized: "no_active_subscription")
                showError = true
            }
        } catch {
            errorMessage = error.localizedDescription
            showError = true
        }
    }

    func manageSubscription() async {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
        do {
            try await AppStore.showManageSubscriptions(in: windowScene)
        } catch {
            errorMessage = error.localizedDescription
            showError = true
        }
    }

    private func updateFromCustomerInfo(_ customerInfo: CustomerInfo) {
        if customerInfo.entitlements[entitlementID]?.isActive == true {
            updateState(.active)
        } else {
            let hasHadEntitlement = customerInfo.entitlements[entitlementID] != nil
            updateState(hasHadEntitlement ? .expired : .inactive)
        }
    }

    private func updateState(_ newState: ProState) {
        proState = newState
        UserDefaults.standard.set(newState.rawValue, forKey: cachedStateKey)
    }

    func totalMonths(for package: Package) -> Int {
        guard let sub = package.storeProduct.subscriptionPeriod else { return 0 }
        switch sub.unit {
        case .year: return sub.value * 12
        case .month: return sub.value
        case .week: return 0
        case .day: return 0
        @unknown default: return 0
        }
    }

    func savingsPercent(for package: Package) -> Int? {
        let sorted = sortedPackages
        guard sorted.count >= 2 else { return nil }

        let shortestPackage = sorted.last!
        let shortMonths = totalMonths(for: shortestPackage)
        guard shortMonths > 0 else { return nil }
        let shortMonthlyPrice = shortestPackage.storeProduct.price / Decimal(shortMonths)

        let pkgMonths = totalMonths(for: package)
        guard pkgMonths > shortMonths else { return nil }
        let pkgMonthlyPrice = package.storeProduct.price / Decimal(pkgMonths)

        let saving = ((shortMonthlyPrice - pkgMonthlyPrice) / shortMonthlyPrice) * 100
        let percent = NSDecimalNumber(decimal: saving).intValue
        return percent > 0 ? percent : nil
    }

    func periodTitle(for package: Package) -> String {
        guard let sub = package.storeProduct.subscriptionPeriod else { return "" }
        switch sub.unit {
        case .month:
            return sub.value == 1 ? String(localized: "per_month") : String(localized: "per_months \(sub.value)")
        case .year:
            return sub.value == 1 ? String(localized: "per_year") : String(localized: "per_years \(sub.value)")
        case .week:
            return sub.value == 1 ? String(localized: "per_week") : String(localized: "per_weeks \(sub.value)")
        case .day:
            return sub.value == 1 ? String(localized: "per_day_sub") : String(localized: "per_days \(sub.value)")
        @unknown default:
            return ""
        }
    }
}
