import SwiftUI
import SwiftData
import RevenueCat

@main
struct InstantRentApp: App {
    @State private var subscriptionService: SubscriptionService
    @State private var currencyManager = CurrencyManager()

    init() {
<<<<<<< HEAD
        let apiKey: String
        #if DEBUG
        Purchases.logLevel = .debug
        apiKey = Config.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY
        #else
        apiKey = Config.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY
        #endif

        if !apiKey.isEmpty {
            Purchases.configure(withAPIKey: apiKey)
        }

=======
        #if DEBUG
        Purchases.logLevel = .debug
        print("[RC] Using DEBUG key:", Config.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY)
        Purchases.configure(withAPIKey: Config.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY)
        RCConfig.isConfigured = true
        #else
        print("[RC] Using RELEASE key:", Config.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY)
        Purchases.configure(withAPIKey: Config.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY)
        RCConfig.isConfigured = true
        #endif

>>>>>>> ed7ae2d (Update iOS project changes)
        let svc = SubscriptionService()
        svc.initialize()
        _subscriptionService = State(initialValue: svc)
    }

    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Car.self,
            Client.self,
            Rental.self,
            ContractTemplate.self,
        ])
        do {
            let config = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
            return try ModelContainer(for: schema, configurations: [config])
        } catch {
            do {
                let memConfig = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
                return try ModelContainer(for: schema, configurations: [memConfig])
            } catch {
                fatalError("Could not create ModelContainer: \(error)")
            }
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(subscriptionService)
                .environment(currencyManager)
                .tint(.orange)
                .hideKeyboardOnTap()
        }
        .modelContainer(sharedModelContainer)
    }
}
