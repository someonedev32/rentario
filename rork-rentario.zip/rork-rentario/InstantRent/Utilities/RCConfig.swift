import Foundation

enum RCConfig {
    static var isConfigured: Bool = false

    // Toggle via Info.plist key EXPO_PUBLIC_USE_RC_TEST_ENV ("true"/"1" to enable)
    private static var useTestEnvironment: Bool {
        let raw = bundleValue(for: "EXPO_PUBLIC_USE_RC_TEST_ENV").lowercased()
        return raw == "1" || raw == "true" || raw == "yes"
    }

    // Public accessor for the API key that should be used right now
    static var currentAPIKey: String {
        let test = testAPIKey
        let prod = prodAPIKey
        if useTestEnvironment, !test.isEmpty { return test }
        return prod
    }

    /// Prefer using 'currentAPIKey'. Exposed for diagnostics and legacy call sites.
    static var testAPIKey: String {
        bundleValue(for: "EXPO_PUBLIC_REVENUECAT_TEST_API_KEY")
    }

    /// Prefer using 'currentAPIKey'. Exposed for diagnostics and legacy call sites.
    static var prodAPIKey: String {
        bundleValue(for: "EXPO_PUBLIC_REVENUECAT_IOS_API_KEY")
    }

    // Call this early in app launch to validate configuration
    @discardableResult
    static func ensureConfigured() -> Bool {
        let key = currentAPIKey
        if key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            debugPrint("[RCConfig] ERROR: RevenueCat API key is empty. Check Info.plist keys 'EXPO_PUBLIC_REVENUECAT_IOS_API_KEY' (prod) and 'EXPO_PUBLIC_REVENUECAT_TEST_API_KEY' (test). Also verify 'EXPO_PUBLIC_USE_RC_TEST_ENV' if you intend to use test.")
            isConfigured = false
            return false
        }
        isConfigured = true
        debugPrint("[RCConfig] Using \(useTestEnvironment ? "TEST" : "PROD") key. \(diagnosticDescription)")
        return true
    }

    // More robust bundle lookup that trims whitespace
    private static func bundleValue(for key: String) -> String {
        if let value = Bundle.main.object(forInfoDictionaryKey: key) as? String {
            return value.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if let dictValue = Bundle.main.infoDictionary?[key] as? String {
            return dictValue.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return ""
    }

    private static var diagnosticDescription: String {
        let testSet = !testAPIKey.isEmpty
        let prodSet = !prodAPIKey.isEmpty
        return "testKeySet=\(testSet) prodKeySet=\(prodSet) useTest=\(useTestEnvironment)"
    }
}
