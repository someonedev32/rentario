import SwiftUI

extension CarStatus {
    var displayName: String {
        switch self {
        case .free: return L10n.free
        case .rented: return L10n.rented
        case .maintenance: return L10n.maintenance
        }
    }

    var color: Color {
        switch self {
        case .free: return .green
        case .rented: return .orange
        case .maintenance: return .red
        }
    }

    var icon: String {
        switch self {
        case .free: return "checkmark.circle.fill"
        case .rented: return "car.fill"
        case .maintenance: return "wrench.fill"
        }
    }
}

extension TransmissionType {
    var displayName: String {
        switch self {
        case .manual: return L10n.manual
        case .automatic: return L10n.automatic
        }
    }
}

extension FuelType {
    var displayName: String {
        switch self {
        case .gasoline: return L10n.gasoline
        case .diesel: return L10n.diesel
        case .electric: return L10n.electric
        case .hybrid: return L10n.hybrid
        case .lpg: return L10n.lpg
        }
    }
}

extension RentalStatus {
    var displayName: String {
        switch self {
        case .active: return L10n.active
        case .completed: return L10n.completed
        case .cancelled: return L10n.cancelled
        }
    }

    var color: Color {
        switch self {
        case .active: return .orange
        case .completed: return .green
        case .cancelled: return .red
        }
    }

    var icon: String {
        switch self {
        case .active: return "clock.fill"
        case .completed: return "checkmark.circle.fill"
        case .cancelled: return "xmark.circle.fill"
        }
    }
}

extension CarColor {
    var displayName: String {
        switch self {
        case .black: return "Black"
        case .white: return "White"
        case .silver: return "Silver"
        case .gray: return "Gray"
        case .red: return "Red"
        case .blue: return "Blue"
        case .darkBlue: return "Dark Blue"
        case .green: return "Green"
        case .brown: return "Brown"
        case .beige: return "Beige"
        case .orange: return "Orange"
        case .yellow: return "Yellow"
        case .burgundy: return "Burgundy"
        }
    }

    var swiftUIColor: Color {
        switch self {
        case .black: return .black
        case .white: return Color(.systemGray5)
        case .silver: return Color(.systemGray3)
        case .gray: return .gray
        case .red: return .red
        case .blue: return .blue
        case .darkBlue: return Color(red: 0.0, green: 0.1, blue: 0.4)
        case .green: return .green
        case .brown: return .brown
        case .beige: return Color(red: 0.96, green: 0.87, blue: 0.70)
        case .orange: return .orange
        case .yellow: return .yellow
        case .burgundy: return Color(red: 0.5, green: 0.0, blue: 0.13)
        }
    }
}

extension Color {
    static let appOrange = Color.orange
    static let appBackground = Color(.systemGroupedBackground)
    static let cardBackground = Color(.secondarySystemGroupedBackground)
}

extension Date {
    var startOfDay: Date {
        Calendar.current.startOfDay(for: self)
    }

    var endOfDay: Date {
        Calendar.current.date(bySettingHour: 23, minute: 59, second: 59, of: self) ?? self
    }

    var startOfWeek: Date {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)
        return calendar.date(from: components) ?? self
    }

    var startOfMonth: Date {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month], from: self)
        return calendar.date(from: components) ?? self
    }
}

extension View {
    func statusBadge(_ status: CarStatus) -> some View {
        self.modifier(StatusBadgeModifier(text: status.displayName, color: status.color))
    }

    func hideKeyboardOnTap() -> some View {
        self.background(
            KeyboardDismissHelper()
        )
    }
}

struct KeyboardDismissHelper: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = KeyboardDismissView()
        view.isUserInteractionEnabled = true
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}

class KeyboardDismissView: UIView {
    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard let window = self.window else { return }
        let hasTap = window.gestureRecognizers?.contains(where: { $0 is KeyboardDismissTapGesture }) ?? false
        if !hasTap {
            let tap = KeyboardDismissTapGesture(target: self, action: #selector(dismissKeyboard))
            tap.cancelsTouchesInView = false
            tap.requiresExclusiveTouchType = false
            window.addGestureRecognizer(tap)
        }
        let hasPan = window.gestureRecognizers?.contains(where: { $0 is KeyboardDismissPanGesture }) ?? false
        if !hasPan {
            let pan = KeyboardDismissPanGesture(target: self, action: #selector(dismissKeyboard))
            pan.cancelsTouchesInView = false
            pan.requiresExclusiveTouchType = false
            pan.delegate = self
            window.addGestureRecognizer(pan)
        }
    }

    @objc private func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

extension KeyboardDismissView: UIGestureRecognizerDelegate {
    nonisolated func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        true
    }
}

class KeyboardDismissTapGesture: UITapGestureRecognizer {}
class KeyboardDismissPanGesture: UIPanGestureRecognizer {}

struct StatusBadgeModifier: ViewModifier {
    let text: String
    let color: Color

    func body(content: Content) -> some View {
        content.overlay(alignment: .topTrailing) {
            Text(text)
                .font(.caption2.weight(.semibold))
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background(color.opacity(0.15))
                .foregroundStyle(color)
                .clipShape(.capsule)
                .padding(8)
        }
    }
}
