// Config.swift
// Centralized configuration values for API keys and environment settings.
// TODO: Replace placeholder values with your actual keys or load from Info.plist / secrets management.

import Foundation

public struct Config {
    // RevenueCat API keys
    // In DEBUG builds, `InstantRentApp` uses this test key.
    public static let EXPO_PUBLIC_REVENUECAT_TEST_API_KEY: String = {
#if DEBUG
    let key = Bundle.main.object(forInfoDictionaryKey: "REVENUECAT_TEST_API_KEY") as? String ?? ""
    assert(!key.isEmpty, "Missing REVENUECAT_TEST_API_KEY in target Info (Debug build)")
    return key.isEmpty ? "rc_test_api_key_placeholder" : key
#else
    // In Release builds this value is not used; keep behavior consistent
    let key = Bundle.main.object(forInfoDictionaryKey: "REVENUECAT_TEST_API_KEY") as? String ?? ""
    return key.isEmpty ? "rc_test_api_key_placeholder" : key
#endif
    }()

    // In RELEASE builds, `InstantRentApp` uses this production key.
    public static let EXPO_PUBLIC_REVENUECAT_IOS_API_KEY: String = {
#if !DEBUG
    let key = Bundle.main.object(forInfoDictionaryKey: "REVENUECAT_IOS_API_KEY") as? String ?? ""
    assert(!key.isEmpty, "Missing REVENUECAT_IOS_API_KEY in target Info (Release build)")
    return key.isEmpty ? "rc_prod_api_key_placeholder" : key
#else
    // In Debug builds this value is not used; keep behavior consistent
    let key = Bundle.main.object(forInfoDictionaryKey: "REVENUECAT_IOS_API_KEY") as? String ?? ""
    return key.isEmpty ? "rc_prod_api_key_placeholder" : key
#endif
    }()
}

