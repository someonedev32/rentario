import SwiftUI
import SwiftData

struct RentalDetailView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Environment(CurrencyManager.self) private var currencyManager
    let rental: Rental
    @State private var showCompleteSheet: Bool = false
    @State private var showCancelConfirm: Bool = false
    @State private var showContractSigning: Bool = false
    @State private var showShareSheet: Bool = false
    @State private var pdfURL: URL?
    @Query private var templates: [ContractTemplate]

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                statusHeader
                carSection
                clientSection
                locationsSection
                datesSection
                pricingSection
                kmSection
                contractSection
                if rental.status == .active {
                    actionsSection
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
        .background(Color.appBackground)
        .navigationTitle(L10n.rentalDetails)
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showCompleteSheet) {
            CompleteRentalSheet(rental: rental)
        }
        .sheet(isPresented: $showContractSigning) {
            ContractSigningView(rental: rental)
        }
        .sheet(isPresented: $showShareSheet) {
            if let url = pdfURL {
                ShareSheetView(items: [url])
            }
        }
        .confirmationDialog(L10n.cancelRental, isPresented: $showCancelConfirm, titleVisibility: .visible) {
            Button(L10n.cancelRental, role: .destructive) {
                rental.status = .cancelled
                rental.car?.status = .free
            }
        }
    }

    private var statusHeader: some View {
        HStack {
            Image(systemName: rental.status.icon)
                .font(.title2)
                .foregroundStyle(rental.status.color)
            Text(rental.status.displayName)
                .font(.title3.weight(.semibold))
                .foregroundStyle(rental.status.color)
            Spacer()
            Text(rental.totalPrice, format: .currency(code: currencyManager.currencyCode))
                .font(.title2.bold())
                .foregroundStyle(.orange)
        }
        .padding(16)
        .background(rental.status.color.opacity(0.08))
        .clipShape(.rect(cornerRadius: 14))
    }

    private var carSection: some View {
        DetailSection(title: L10n.carDetails) {
            if let car = rental.car {
                NavigationLink(destination: CarDetailView(car: car)) {
                    HStack(spacing: 12) {
                        Image(systemName: "car.fill")
                            .font(.title3)
                            .foregroundStyle(.orange)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(car.displayName)
                                .font(.subheadline.weight(.semibold))
                            Text(car.licensePlate)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var clientSection: some View {
        DetailSection(title: L10n.clientDetails) {
            if let client = rental.client {
                NavigationLink(destination: ClientDetailView(client: client)) {
                    HStack(spacing: 12) {
                        Text(client.fullName.prefix(2).uppercased())
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .frame(width: 36, height: 36)
                            .background(Color.orange.gradient)
                            .clipShape(Circle())
                        VStack(alignment: .leading, spacing: 2) {
                            Text(client.fullName)
                                .font(.subheadline.weight(.semibold))
                            if !client.phone.isEmpty {
                                Text(client.phone)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var locationsSection: some View {
        if !rental.pickupLocation.isEmpty || !rental.dropoffLocation.isEmpty {
            DetailSection(title: L10n.locations) {
                if !rental.pickupLocation.isEmpty {
                    HStack(spacing: 8) {
                        Image(systemName: "mappin.circle.fill")
                            .foregroundStyle(.orange)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L10n.pickupLocationLabel)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text(rental.pickupLocation)
                                .font(.subheadline.weight(.medium))
                        }
                    }
                }
                if !rental.dropoffLocation.isEmpty {
                    HStack(spacing: 8) {
                        Image(systemName: "mappin.circle")
                            .foregroundStyle(.secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L10n.dropoffLocationLabel)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text(rental.dropoffLocation)
                                .font(.subheadline.weight(.medium))
                        }
                    }
                }
            }
        }
    }

    private var datesSection: some View {
        DetailSection(title: L10n.rentalPeriod) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L10n.pickupDate)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(rental.pickupDate, format: .dateTime.month(.abbreviated).day().year())
                        .font(.subheadline.weight(.medium))
                    Text(rental.pickupDate, format: .dateTime.hour().minute())
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "arrow.right")
                    .foregroundStyle(.tertiary)
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(L10n.returnDate)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(rental.returnDate, format: .dateTime.month(.abbreviated).day().year())
                        .font(.subheadline.weight(.medium))
                    Text(rental.returnDate, format: .dateTime.hour().minute())
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            HStack {
                Text(L10n.duration)
                    .foregroundStyle(.secondary)
                Spacer()
                Text("\(rental.numberOfDays) " + L10n.days)
                    .font(.subheadline.weight(.medium))
            }
        }
    }

    private var pricingSection: some View {
        DetailSection(title: L10n.pricingDetails) {
            HStack {
                Text(L10n.dailyRate)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(rental.dailyRate, format: .currency(code: currencyManager.currencyCode))
            }
            .font(.subheadline)

            if !rental.extras.isEmpty {
                ForEach(rental.extras) { extra in
                    HStack {
                        Text(extra.name)
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text(extra.pricePerDay, format: .currency(code: currencyManager.currencyCode))
                        Text(extra.isFlat ? L10n.flat : L10n.perDay)
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                    .font(.subheadline)
                }
            }

            if rental.discountType != "none" && rental.discountValue > 0 {
                HStack {
                    Text(L10n.discount)
                        .foregroundStyle(.secondary)
                    Spacer()
                    if rental.discountType == "percentage" {
                        Text("-\(rental.discountValue, specifier: "%.0f")%")
                            .foregroundStyle(.green)
                    } else {
                        Text(rental.discountValue, format: .currency(code: currencyManager.currencyCode))
                            .foregroundStyle(.green)
                    }
                }
                .font(.subheadline)
            }

            Divider()

            HStack {
                Text(L10n.totalPrice)
                    .font(.headline)
                Spacer()
                Text(rental.totalPrice, format: .currency(code: currencyManager.currencyCode))
                    .font(.headline)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var kmSection: some View {
        DetailSection(title: L10n.kmTracking) {
            HStack {
                Text(L10n.kmAtPickup)
                    .foregroundStyle(.secondary)
                Spacer()
                Text("\(rental.kmAtPickup) km")
                    .font(.subheadline.weight(.medium))
            }
            if let kmReturn = rental.kmAtReturn {
                HStack {
                    Text(L10n.kmAtReturn)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("\(kmReturn) km")
                        .font(.subheadline.weight(.medium))
                }
                HStack {
                    Text(L10n.kmDriven)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("\(kmReturn - rental.kmAtPickup) km")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.orange)
                }
            }
        }
    }

    private var contractSection: some View {
        DetailSection(title: L10n.contract) {
            if rental.contractPDFPath != nil {
                Button(action: sharePDF) {
                    Label(L10n.shareContract, systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Button(action: printPDF) {
                    Label(L10n.printContract, systemImage: "printer")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            } else {
                Button(action: { showContractSigning = true }) {
                    Label(L10n.generateContract, systemImage: "doc.text.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
            }
        }
    }

    private var actionsSection: some View {
        VStack(spacing: 12) {
            Button(action: { showCompleteSheet = true }) {
                Label(L10n.completeRental, systemImage: "checkmark.circle.fill")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)

            Button(role: .destructive, action: { showCancelConfirm = true }) {
                Label(L10n.cancelRental, systemImage: "xmark.circle.fill")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 4)
            }
            .buttonStyle(.bordered)
        }
    }

    private func sharePDF() {
        guard let path = rental.contractPDFPath else { return }
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = docs.appendingPathComponent(path)
        pdfURL = url
        showShareSheet = true
    }

    private func printPDF() {
        guard let path = rental.contractPDFPath else { return }
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = docs.appendingPathComponent(path)
        let printController = UIPrintInteractionController.shared
        printController.printingItem = url
        printController.present(animated: true)
    }
}

struct CompleteRentalSheet: View {
    @Environment(\.dismiss) private var dismiss
    let rental: Rental
    @State private var kmAtReturn: Int = 0

    var body: some View {
        NavigationStack {
            Form {
                Section(L10n.kmAtReturn) {
                    TextField("0", value: $kmAtReturn, format: .number)
                        .keyboardType(.numberPad)
                }
            }
            .navigationTitle(L10n.completeRental)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.cancel) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(L10n.confirm) {
                        rental.kmAtReturn = kmAtReturn
                        rental.actualReturnDate = Date()
                        rental.status = .completed
                        if let car = rental.car {
                            car.odometer = kmAtReturn
                            car.status = .free
                        }
                        dismiss()
                    }
                    .fontWeight(.semibold)
                }
            }
            .onAppear {
                kmAtReturn = rental.car?.odometer ?? rental.kmAtPickup
            }
        }
    }
}

struct ShareSheetView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
