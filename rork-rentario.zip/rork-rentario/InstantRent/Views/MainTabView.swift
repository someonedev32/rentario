import SwiftUI

struct MainTabView: View {
    @State private var selectedTab: Int = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            Tab(L10n.dashboard, systemImage: "square.grid.2x2.fill", value: 0) {
                DashboardView()
            }
            Tab(L10n.calendar, systemImage: "calendar", value: 1) {
                CalendarView()
            }
            Tab(L10n.cars, systemImage: "car.fill", value: 2) {
                CarsListView()
            }
            Tab(L10n.clients, systemImage: "person.2.fill", value: 3) {
                ClientsListView()
            }
            Tab(L10n.settings, systemImage: "gearshape.fill", value: 4) {
                SettingsView()
            }
        }
    }
}
