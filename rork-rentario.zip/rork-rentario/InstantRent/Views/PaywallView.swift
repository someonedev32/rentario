import SwiftUI
import RevenueCat

struct PaywallView: View {
    @Environment(SubscriptionService.self) private var subscriptionService
    @Environment(\.dismiss) private var dismiss
    var onDismiss: (() -> Void)?
    @State private var selectedPackage: Package?
    @State private var hasAutoSelected: Bool = false

    private func autoSelectYearly() {
        guard !hasAutoSelected, !subscriptionService.sortedPackages.isEmpty else { return }
        hasAutoSelected = true
        let yearly = subscriptionService.sortedPackages.first(where: { pkg in
            pkg.storeProduct.subscriptionPeriod?.unit == .year
        }) ?? subscriptionService.sortedPackages.first
        selectedPackage = yearly
    }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.orange.opacity(0.12), Color(.systemBackground)],
                startPoint: .top,
                endPoint: .center
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 14) {
                    Spacer().frame(height: 8)
                    HStack {
                        Spacer()
                        Button {
                            if let onDismiss {
                                onDismiss()
                            } else {
                                dismiss()
                            }
                        } label: {
                            Image(systemName: "xmark")
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(.secondary)
                                .frame(width: 28, height: 28)
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                        }
                    }

                    switch subscriptionService.proState {
                    case .active:
                        activeSubscriptionContent
                    case .expired:
                        expiredContent
                    case .inactive:
                        inactiveContent
                    }

                    Spacer().frame(height: 8)
                }
                .padding(.horizontal, 24)
            }
        }
        .task {
            await subscriptionService.fetchOfferings()
            autoSelectYearly()
        }
        .onChange(of: subscriptionService.sortedPackages.count) { _, _ in
            autoSelectYearly()
        }
        .alert(L10n.error, isPresented: Binding(
            get: { subscriptionService.showError },
            set: { subscriptionService.showError = $0 }
        )) {
            Button(L10n.ok) {}
        } message: {
            Text(subscriptionService.errorMessage ?? "")
        }
    }

    private var activeSubscriptionContent: some View {
        VStack(spacing: 20) {
            brandingSection

            VStack(spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 48))
                    .foregroundStyle(.green)
                Text(String(localized: "Pro Active"))
                    .font(.title3.weight(.semibold))
                Text(String(localized: "All Pro features enabled"))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .padding(.vertical, 20)

            Button {
                if let onDismiss {
                    onDismiss()
                } else {
                    dismiss()
                }
            } label: {
                Label(String(localized: "Go to App"), systemImage: "arrow.right.circle.fill")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .tint(.orange)
            .clipShape(.rect(cornerRadius: 14))
        }
    }

    private var expiredContent: some View {
        VStack(spacing: 14) {
            brandingSection

            VStack(spacing: 12) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 44))
                    .foregroundStyle(.orange)
                Text(String(localized: "pro_expired_title"))
                    .font(.title3.weight(.semibold))
                Text(String(localized: "Your subscription has expired. Renew to continue using all Pro features."))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(.vertical, 12)

            featuresSection
            packagesSection
            ctaButton

            footerSection
        }
    }

    private var inactiveContent: some View {
        VStack(spacing: 14) {
            brandingSection
            featuresSection
            packagesSection
            ctaButton

            footerSection
        }
    }

    private var brandingSection: some View {
        VStack(spacing: 6) {
            Image("AppIconImage")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 72, height: 72)
                .clipShape(.rect(cornerRadius: 18))
                .shadow(color: .orange.opacity(0.25), radius: 8, y: 4)

            Text("Rentario")
                .font(.title2.bold())

            Text(String(localized: "start_free_trial_heading"))
                .font(.subheadline.weight(.semibold))
                .multilineTextAlignment(.center)
        }
    }

    private var featuresSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            FeatureRow(icon: "car.2.fill", color: .orange, text: L10n.paywall_feature1)
            FeatureRow(icon: "doc.text.fill", color: .blue, text: L10n.paywall_feature2)
            FeatureRow(icon: "calendar.badge.clock", color: .green, text: L10n.paywall_feature3)
            FeatureRow(icon: "person.2.fill", color: .purple, text: L10n.paywall_feature4)
            FeatureRow(icon: "signature", color: .indigo, text: String(localized: "paywall_feature5"))
            FeatureRow(icon: "bolt.shield.fill", color: .red, text: String(localized: "paywall_feature6"))
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(.rect(cornerRadius: 14))
    }

    private var packagesSection: some View {
        VStack(spacing: 8) {
            if subscriptionService.isLoading {
                ProgressView()
                    .frame(height: 120)
            } else if !subscriptionService.sortedPackages.isEmpty {
                ForEach(subscriptionService.sortedPackages, id: \.identifier) { package in
                    PackageCard(
                        package: package,
                        isSelected: selectedPackage?.identifier == package.identifier,
                        savingsPercent: subscriptionService.savingsPercent(for: package),
                        isBestValue: package.identifier == subscriptionService.sortedPackages.first?.identifier && subscriptionService.sortedPackages.count > 1,
                        periodTitle: subscriptionService.periodTitle(for: package)
                    ) {
                        selectedPackage = package
                    }
                }
            } else {
                VStack(spacing: 12) {
                    Text(String(localized: "Unable to load subscription options"))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    Button {
                        Task { await subscriptionService.fetchOfferings() }
                    } label: {
                        Label(String(localized: "Try Again"), systemImage: "arrow.clockwise")
                            .font(.subheadline.weight(.medium))
                    }
                    .buttonStyle(.bordered)
                    .tint(.orange)
                }
                .frame(height: 100)
            }
        }
    }

    private var ctaButtonTitle: String {
        guard let package = selectedPackage,
              let intro = package.storeProduct.introductoryDiscount,
              intro.price == 0 else {
            return subscriptionService.proState == .expired
                ? String(localized: "resubscribe")
                : L10n.startFreeTrial
        }
        let period = intro.subscriptionPeriod
        let durationText: String
        switch period.unit {
        case .day:
            durationText = period.value == 1 ? String(localized: "1 Day") : String(localized: "\(period.value) Days")
        case .week:
            durationText = period.value == 1 ? String(localized: "1 Week") : String(localized: "\(period.value) Weeks")
        case .month:
            durationText = period.value == 1 ? String(localized: "1 Month") : String(localized: "\(period.value) Months")
        case .year:
            durationText = period.value == 1 ? String(localized: "1 Year") : String(localized: "\(period.value) Years")
        @unknown default:
            durationText = ""
        }
        return String(localized: "Start \(durationText) Free Trial")
    }

    private var ctaButton: some View {
        Group {
            if !subscriptionService.sortedPackages.isEmpty {
                VStack(spacing: 10) {
                    Button(action: {
                        guard let package = selectedPackage else { return }
                        Task { await subscriptionService.purchase(package) }
                    }) {
                        Group {
                            if subscriptionService.isPurchasing {
                                ProgressView()
                                    .tint(.white)
                            } else {
                                Text(ctaButtonTitle)
                                    .fontWeight(.bold)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.orange)
                    .disabled(selectedPackage == nil || subscriptionService.isPurchasing)
                    .clipShape(.rect(cornerRadius: 14))
                }
            }
        }
    }

    private var dynamicTrialInfo: String {
        let sorted = subscriptionService.sortedPackages
        guard !sorted.isEmpty else { return "" }

        let priceParts = sorted.map { package -> String in
            let price = package.localizedPriceString
            let period = subscriptionService.periodTitle(for: package)
            return "\(price) \(period)"
        }

        let pricesText: String
        if priceParts.count == 1 {
            pricesText = priceParts[0]
        } else {
            let allButLast = priceParts.dropLast().joined(separator: ", ")
            pricesText = "\(allButLast) " + String(localized: "or_conjunction") + " \(priceParts.last!)"
        }

        let trialText = String(localized: "dynamic_trial_prefix")
        let autoRenewText = String(localized: "dynamic_trial_autorenew")
        let manageText = String(localized: "dynamic_trial_manage")

        return "\(trialText) \(pricesText). \(autoRenewText) \(manageText)"
    }

    private var footerSection: some View {
        VStack(spacing: 6) {
            Text(dynamicTrialInfo)
                .font(.caption2)
                .foregroundStyle(.tertiary)
                .multilineTextAlignment(.center)

            HStack(spacing: 4) {
                Link(String(localized: "privacy_policy"), destination: URL(string: "https://sites.google.com/view/renatrio/home")!)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)

                Text("·")
                    .font(.caption2)
                    .foregroundStyle(.quaternary)

                Link(String(localized: "terms_of_use"), destination: URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)

                Text("·")
                    .font(.caption2)
                    .foregroundStyle(.quaternary)

                Button(action: {
                    Task { await subscriptionService.restorePurchases() }
                }) {
                    Text(L10n.restorePurchases)
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }
}

struct FeatureRow: View {
    let icon: String
    let color: Color
    let text: String

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.footnote)
                .foregroundStyle(color)
                .frame(width: 30, height: 30)
                .background(color.opacity(0.12))
                .clipShape(.rect(cornerRadius: 7))
            Text(text)
                .font(.subheadline)
            Spacer()
        }
    }
}

struct PackageCard: View {
    let package: Package
    let isSelected: Bool
    var savingsPercent: Int?
    var isBestValue: Bool = false
    let periodTitle: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 0) {
                if isBestValue {
                    Text(String(localized: "best_value"))
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                        .background(Color.orange)
                }

                HStack(spacing: 0) {
                    ZStack {
                        Circle()
                            .stroke(isSelected ? Color.orange : Color(.tertiaryLabel), lineWidth: 2)
                            .frame(width: 22, height: 22)
                        if isSelected {
                            Circle()
                                .fill(Color.orange)
                                .frame(width: 14, height: 14)
                        }
                    }
                    .padding(.trailing, 12)

                    VStack(alignment: .leading, spacing: 2) {
                        HStack(spacing: 6) {
                            Text(package.storeProduct.localizedTitle)
                                .font(.subheadline.weight(.semibold))
                            if let percent = savingsPercent {
                                Text(String(localized: "save_percent \(percent)"))
                                    .font(.caption2.weight(.bold))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.orange.gradient)
                                    .clipShape(.capsule)
                            }
                        }
                        Text(periodTitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    Text(package.localizedPriceString)
                        .font(.title3.weight(.bold))
                        .foregroundStyle(isSelected ? .orange : .primary)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
            }
            .background(isSelected ? Color.orange.opacity(0.06) : Color(.secondarySystemGroupedBackground))
            .clipShape(.rect(cornerRadius: 14))
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(isSelected ? Color.orange : Color(.separator).opacity(0.3), lineWidth: isSelected ? 2 : 1)
            )
        }
        .buttonStyle(.plain)
        .sensoryFeedback(.selection, trigger: isSelected)
    }
}
