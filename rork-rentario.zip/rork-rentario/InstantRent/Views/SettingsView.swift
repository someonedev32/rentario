import SwiftUI
import SwiftData
import StoreKit

struct SettingsView: View {
    @Environment(SubscriptionService.self) private var subscriptionService
    @Environment(CurrencyManager.self) private var currencyManager
    @Environment(\.modelContext) private var modelContext
    @Query private var templates: [ContractTemplate]
    @State private var showTemplateEditor: Bool = false
    @State private var editingTemplate: ContractTemplate?
    @State private var showPaywall: Bool = false

    var body: some View {
        NavigationStack {
            Form {
                subscriptionSection
                currencySection
                contractSection
                dataStorageSection
            }
            .navigationTitle(L10n.settings)
            .sheet(isPresented: $showTemplateEditor) {
                ContractTemplateEditorView(template: editingTemplate)
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
        }
    }

    private var subscriptionSection: some View {
        Section(L10n.subscription) {
            switch subscriptionService.proState {
            case .active:
                HStack {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundStyle(.green)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(L10n.proActiveTitle)
                            .font(.subheadline.weight(.semibold))
                        Text(L10n.allProFeaturesEnabled)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text(L10n.activeSub)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.green)
                }

                Button(action: {
                    Task { await subscriptionService.manageSubscription() }
                }) {
                    HStack {
                        Label(L10n.changeOrCancelPlan, systemImage: "arrow.up.arrow.down.circle")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.tertiary)
                    }
                }

                Button(action: {
                    Task { await subscriptionService.restorePurchases() }
                }) {
                    Label(L10n.restorePurchases, systemImage: "arrow.clockwise")
                }

                redeemCodeButton

            case .expired:
                HStack {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(L10n.proExpiredTitle)
                            .font(.subheadline.weight(.semibold))
                        Text(L10n.proExpiredSubtitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text(L10n.expiredLabel)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.orange)
                }

                Button(action: {
                    showPaywall = true
                }) {
                    Label(L10n.resubscribe, systemImage: "arrow.clockwise.circle.fill")
                        .foregroundStyle(.orange)
                }

                redeemCodeButton

            case .inactive:
                Button(action: {
                    showPaywall = true
                }) {
                    HStack {
                        Image(systemName: "crown.fill")
                            .foregroundStyle(.orange)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L10n.upgradeToPro)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.primary)
                            Text(L10n.unlockPremiumFeatures)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.tertiary)
                    }
                }

                redeemCodeButton
            }
        }
    }

    private var redeemCodeButton: some View {
        Button(action: {
            Task {
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
                do {
                    try await AppStore.presentOfferCodeRedeemSheet(in: windowScene)
                } catch {
                }
            }
        }) {
            VStack(alignment: .leading, spacing: 2) {
                Label(L10n.redeemCode, systemImage: "giftcard")
                Text(L10n.redeemCodeDescription)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var currencySection: some View {
        @Bindable var cm = currencyManager
        return Section(L10n.currency) {
            Picker(L10n.currency, selection: $cm.selected) {
                ForEach(AppCurrency.allCases) { currency in
                    Text(currency.displayName).tag(currency)
                }
            }
        }
    }

    private var contractSection: some View {
        Section(L10n.contractTemplate) {
            if templates.isEmpty {
                Button(action: {
                    editingTemplate = nil
                    showTemplateEditor = true
                }) {
                    Label(L10n.createDefaultTemplate, systemImage: "doc.badge.plus")
                }
            } else {
                ForEach(templates) { template in
                    Button(action: {
                        editingTemplate = template
                        showTemplateEditor = true
                    }) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(template.name)
                                    .font(.subheadline)
                                    .foregroundStyle(.primary)
                                Text(template.createdAt, style: .date)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if template.isDefault {
                                Text(L10n.defaultLabel)
                                    .font(.caption2.weight(.semibold))
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 3)
                                    .background(Color.orange.opacity(0.12))
                                    .foregroundStyle(.orange)
                                    .clipShape(.capsule)
                            }
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }
                }
                .onDelete(perform: deleteTemplates)

                Button(action: {
                    editingTemplate = nil
                    showTemplateEditor = true
                }) {
                    Label(L10n.addTemplate, systemImage: "plus.circle")
                }
            }
        }
    }

    private var dataStorageSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    Image(systemName: "externaldrive.fill")
                        .font(.title3)
                        .foregroundStyle(.green)
                    Text(L10n.dataStorage)
                        .font(.subheadline.weight(.semibold))
                }
                Text(L10n.allDataStoredLocally)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Divider()
                HStack(spacing: 8) {
                    Image(systemName: "wifi")
                        .font(.caption)
                        .foregroundStyle(.green)
                    Text(L10n.worksOffline)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 4)
        }
    }


    private func deleteTemplates(at offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(templates[index])
        }
    }
}
