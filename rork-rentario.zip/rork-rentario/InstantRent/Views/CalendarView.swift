import SwiftUI
import SwiftData

nonisolated enum CalendarMode: String, CaseIterable, Sendable {
    case daily
    case weekly
    case monthly
    case yearly
}

struct CalendarView: View {
    @Environment(SubscriptionService.self) private var subscriptionService
    @Query(sort: \Rental.pickupDate) private var allRentals: [Rental]
    @State private var selectedDate: Date = Date()
    @State private var mode: CalendarMode = .daily
    @State private var showNewRental: Bool = false
    @State private var showPaywall: Bool = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Mode", selection: $mode) {
                    Text(L10n.daily).tag(CalendarMode.daily)
                    Text(L10n.weekly).tag(CalendarMode.weekly)
                    Text(L10n.month).tag(CalendarMode.monthly)
                    Text(L10n.yearView).tag(CalendarMode.yearly)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.vertical, 8)

                switch mode {
                case .daily:
                    DailyCalendarView(selectedDate: $selectedDate, rentals: allRentals)
                case .weekly:
                    WeeklyCalendarView(selectedDate: $selectedDate, rentals: allRentals)
                case .monthly:
                    MonthlyCalendarView(selectedDate: $selectedDate, rentals: allRentals)
                case .yearly:
                    YearlyCalendarView(selectedDate: $selectedDate, rentals: allRentals)
                }
            }
            .background(Color.appBackground)
            .navigationTitle(L10n.calendar)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        if subscriptionService.isProUser { showNewRental = true } else { showPaywall = true }
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showNewRental) {
                NewRentalView()
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
        }
    }
}

struct DailyCalendarView: View {
    @Environment(\.modelContext) private var modelContext
    @Binding var selectedDate: Date
    let rentals: [Rental]
    @State private var rentalToDelete: Rental?
    @State private var showDeleteConfirmation: Bool = false

    private var rentalsForDay: [Rental] {
        let cal = Calendar.current
        return rentals.filter { rental in
            let start = cal.startOfDay(for: rental.pickupDate)
            let end = cal.startOfDay(for: rental.returnDate)
            let selected = cal.startOfDay(for: selectedDate)
            return selected >= start && selected <= end && rental.status != .cancelled
        }
    }

    private func deleteRental(_ rental: Rental) {
        if rental.status == .active {
            rental.car?.status = .free
        }
        modelContext.delete(rental)
    }

    var body: some View {
        VStack(spacing: 0) {
            DatePicker(L10n.pickupDate, selection: $selectedDate, displayedComponents: .date)
                .datePickerStyle(.graphical)
                .tint(.orange)
                .padding(.horizontal)

            Divider()

            if rentalsForDay.isEmpty {
                ContentUnavailableView(L10n.noRentals, systemImage: "calendar.badge.exclamationmark")
                    .frame(maxHeight: .infinity)
            } else {
                List(rentalsForDay) { rental in
                    NavigationLink(destination: RentalDetailView(rental: rental)) {
                        RentalCalendarRow(rental: rental)
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            rentalToDelete = rental
                            showDeleteConfirmation = true
                        } label: {
                            Label(L10n.delete, systemImage: "trash")
                        }
                    }
                }
                .listStyle(.plain)
            }
        }
        .confirmationDialog(L10n.delete, isPresented: $showDeleteConfirmation, presenting: rentalToDelete) { rental in
            Button(L10n.delete, role: .destructive) {
                deleteRental(rental)
            }
        } message: { rental in
            Text(L10n.deleteRentalConfirm)
        }
    }
}

struct WeeklyCalendarView: View {
    @Binding var selectedDate: Date
    let rentals: [Rental]
    @Query(sort: \Car.make) private var cars: [Car]

    private var weekDays: [Date] {
        let cal = Calendar.current
        let start = selectedDate.startOfWeek
        return (0..<7).compactMap { cal.date(byAdding: .day, value: $0, to: start) }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button(action: { moveWeek(-1) }) {
                    Image(systemName: "chevron.left")
                }
                Spacer()
                Text(weekRangeText)
                    .font(.headline)
                Spacer()
                Button(action: { moveWeek(1) }) {
                    Image(systemName: "chevron.right")
                }
            }
            .padding()

            ScrollView(.horizontal) {
                HStack(alignment: .top, spacing: 2) {
                    ForEach(weekDays, id: \.self) { day in
                        VStack(spacing: 4) {
                            Text(day, format: .dateTime.weekday(.abbreviated))
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(.secondary)
                            Text(day, format: .dateTime.day())
                                .font(.subheadline.weight(.medium))

                            ForEach(rentalsForDay(day)) { rental in
                                NavigationLink(destination: RentalDetailView(rental: rental)) {
                                    Text(rental.car?.licensePlate ?? "—")
                                        .font(.caption2)
                                        .lineLimit(1)
                                        .padding(.horizontal, 6)
                                        .padding(.vertical, 3)
                                        .frame(maxWidth: .infinity)
                                        .background(rental.status.color.opacity(0.2))
                                        .foregroundStyle(rental.status.color)
                                        .clipShape(.rect(cornerRadius: 4))
                                }
                                .buttonStyle(.plain)
                            }
                            Spacer()
                        }
                        .frame(width: 90)
                        .padding(.vertical, 8)
                        .background(Calendar.current.isDateInToday(day) ? Color.orange.opacity(0.08) : Color.clear)
                        .clipShape(.rect(cornerRadius: 8))
                    }
                }
                .contentMargins(.horizontal, 16)
            }

            Spacer()
        }
    }

    private func rentalsForDay(_ day: Date) -> [Rental] {
        let cal = Calendar.current
        let dayStart = cal.startOfDay(for: day)
        return rentals.filter { rental in
            let start = cal.startOfDay(for: rental.pickupDate)
            let end = cal.startOfDay(for: rental.returnDate)
            return dayStart >= start && dayStart <= end && rental.status != .cancelled
        }
    }

    private func moveWeek(_ direction: Int) {
        if let newDate = Calendar.current.date(byAdding: .weekOfYear, value: direction, to: selectedDate) {
            selectedDate = newDate
        }
    }

    private var weekRangeText: String {
        let days = weekDays
        guard let first = days.first, let last = days.last else { return "" }
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d"
        return "\(formatter.string(from: first)) - \(formatter.string(from: last))"
    }
}

struct MonthlyCalendarView: View {
    @Environment(\.modelContext) private var modelContext
    @Binding var selectedDate: Date
    let rentals: [Rental]
    @State private var rentalToDelete: Rental?
    @State private var showDeleteConfirmation: Bool = false

    private let calendar = Calendar.current
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 2), count: 7)

    private var currentMonth: Date {
        calendar.date(from: calendar.dateComponents([.year, .month], from: selectedDate)) ?? selectedDate
    }

    private var daysInMonth: [Date?] {
        guard let range = calendar.range(of: .day, in: .month, for: currentMonth) else { return [] }
        let firstDay = currentMonth
        let weekdayOffset = (calendar.component(.weekday, from: firstDay) - calendar.firstWeekday + 7) % 7
        var days: [Date?] = Array(repeating: nil, count: weekdayOffset)
        for day in range {
            if let date = calendar.date(byAdding: .day, value: day - 1, to: firstDay) {
                days.append(date)
            }
        }
        return days
    }

    private func rentalCount(for date: Date) -> Int {
        let dayStart = calendar.startOfDay(for: date)
        return rentals.filter { rental in
            let start = calendar.startOfDay(for: rental.pickupDate)
            let end = calendar.startOfDay(for: rental.returnDate)
            return dayStart >= start && dayStart <= end && rental.status != .cancelled
        }.count
    }

    private var monthTitle: String {
        selectedDate.formatted(.dateTime.month(.wide).year())
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { moveMonth(-1) } label: {
                    Image(systemName: "chevron.left")
                        .fontWeight(.semibold)
                }
                Spacer()
                Text(monthTitle)
                    .font(.headline)
                Spacer()
                Button { moveMonth(1) } label: {
                    Image(systemName: "chevron.right")
                        .fontWeight(.semibold)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 12)

            LazyVGrid(columns: columns, spacing: 2) {
                ForEach(calendar.shortWeekdaySymbols, id: \.self) { symbol in
                    Text(symbol)
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                }

                ForEach(Array(daysInMonth.enumerated()), id: \.offset) { _, date in
                    if let date {
                        let count = rentalCount(for: date)
                        let isToday = calendar.isDateInToday(date)
                        let isSelected = calendar.isDate(date, inSameDayAs: selectedDate)

                        Button {
                            selectedDate = date
                        } label: {
                            VStack(spacing: 2) {
                                Text("\(calendar.component(.day, from: date))")
                                    .font(.subheadline.weight(isToday ? .bold : .regular))
                                    .foregroundStyle(isSelected ? .white : isToday ? .orange : .primary)

                                if count > 0 {
                                    Text("\(count)")
                                        .font(.system(size: 9, weight: .bold))
                                        .foregroundStyle(isSelected ? .white.opacity(0.9) : .orange)
                                } else {
                                    Text(" ")
                                        .font(.system(size: 9))
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 6)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(isSelected ? Color.orange : Color.clear)
                            )
                        }
                        .buttonStyle(.plain)
                    } else {
                        Color.clear
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 6)
                    }
                }
            }
            .padding(.horizontal)

            Divider()
                .padding(.top, 12)

            let dayRentals = rentalsForSelectedDay
            if dayRentals.isEmpty {
                ContentUnavailableView(L10n.noRentals, systemImage: "calendar.badge.exclamationmark")
                    .frame(maxHeight: .infinity)
            } else {
                List(dayRentals) { rental in
                    NavigationLink(destination: RentalDetailView(rental: rental)) {
                        RentalCalendarRow(rental: rental)
                    }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            rentalToDelete = rental
                            showDeleteConfirmation = true
                        } label: {
                            Label(L10n.delete, systemImage: "trash")
                        }
                    }
                }
                .listStyle(.plain)
            }
        }
        .confirmationDialog(L10n.delete, isPresented: $showDeleteConfirmation, presenting: rentalToDelete) { rental in
            Button(L10n.delete, role: .destructive) {
                deleteRentalMonthly(rental)
            }
        } message: { rental in
            Text(L10n.deleteRentalConfirm)
        }
    }

    private func deleteRentalMonthly(_ rental: Rental) {
        if rental.status == .active {
            rental.car?.status = .free
        }
        modelContext.delete(rental)
    }

    private var rentalsForSelectedDay: [Rental] {
        let dayStart = calendar.startOfDay(for: selectedDate)
        return rentals.filter { rental in
            let start = calendar.startOfDay(for: rental.pickupDate)
            let end = calendar.startOfDay(for: rental.returnDate)
            return dayStart >= start && dayStart <= end && rental.status != .cancelled
        }
    }

    private func moveMonth(_ direction: Int) {
        if let newDate = calendar.date(byAdding: .month, value: direction, to: selectedDate) {
            selectedDate = newDate
        }
    }
}

struct YearlyCalendarView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(CurrencyManager.self) private var currencyManager
    @Binding var selectedDate: Date
    let rentals: [Rental]
    @State private var rentalToDelete: Rental?
    @State private var showDeleteConfirmation: Bool = false

    private let calendar = Calendar.current
    private let monthColumns = Array(repeating: GridItem(.flexible(), spacing: 12), count: 3)

    private var currentYear: Int {
        calendar.component(.year, from: selectedDate)
    }

    private var monthsInYear: [Date] {
        (0..<12).compactMap { month in
            calendar.date(from: DateComponents(year: currentYear, month: month + 1, day: 1))
        }
    }

    private func rentalCount(for monthDate: Date) -> Int {
        guard let range = calendar.range(of: .day, in: .month, for: monthDate) else { return 0 }
        let monthStart = calendar.startOfDay(for: monthDate)
        guard let monthEnd = calendar.date(byAdding: .day, value: range.count - 1, to: monthStart) else { return 0 }
        return rentals.filter { rental in
            let start = calendar.startOfDay(for: rental.pickupDate)
            let end = calendar.startOfDay(for: rental.returnDate)
            return end >= monthStart && start <= monthEnd && rental.status != .cancelled
        }.count
    }

    private func revenue(for monthDate: Date) -> Double {
        guard let range = calendar.range(of: .day, in: .month, for: monthDate) else { return 0 }
        let monthStart = calendar.startOfDay(for: monthDate)
        guard let monthEnd = calendar.date(byAdding: .day, value: range.count - 1, to: monthStart) else { return 0 }
        return rentals.filter { rental in
            let start = calendar.startOfDay(for: rental.pickupDate)
            let end = calendar.startOfDay(for: rental.returnDate)
            return end >= monthStart && start <= monthEnd && rental.status == .completed
        }.reduce(0) { $0 + $1.totalPrice }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Button { moveYear(-1) } label: {
                    Image(systemName: "chevron.left")
                        .fontWeight(.semibold)
                }
                Spacer()
                Text(String(currentYear))
                    .font(.headline)
                Spacer()
                Button { moveYear(1) } label: {
                    Image(systemName: "chevron.right")
                        .fontWeight(.semibold)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 12)

            ScrollView {
                LazyVGrid(columns: monthColumns, spacing: 12) {
                    ForEach(monthsInYear, id: \.self) { monthDate in
                        let count = rentalCount(for: monthDate)
                        let rev = revenue(for: monthDate)
                        let isCurrentMonth = calendar.isDate(monthDate, equalTo: Date(), toGranularity: .month)
                        let isSelected = calendar.isDate(monthDate, equalTo: selectedDate, toGranularity: .month)

                        Button {
                            selectedDate = monthDate
                        } label: {
                            VStack(spacing: 6) {
                                Text(monthDate.formatted(.dateTime.month(.abbreviated)))
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(isSelected ? .white : isCurrentMonth ? .orange : .primary)

                                Text("\(count)")
                                    .font(.title2.weight(.bold))
                                    .foregroundStyle(isSelected ? .white : .primary)

                                Text(count == 1 ? L10n.rental : L10n.rentalsPlural)
                                    .font(.caption2)
                                    .foregroundStyle(isSelected ? .white.opacity(0.8) : .secondary)

                                if rev > 0 {
                                    Text(rev, format: .currency(code: currencyManager.currencyCode))
                                        .font(.caption2.weight(.medium))
                                        .foregroundStyle(isSelected ? .white.opacity(0.9) : .orange)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(
                                RoundedRectangle(cornerRadius: 12)
                                    .fill(isSelected ? Color.orange : Color(.secondarySystemBackground))
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal)

                let monthRentals = rentalsForSelectedMonth
                if !monthRentals.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(selectedDate.formatted(.dateTime.month(.wide).year()))
                            .font(.headline)
                            .padding(.horizontal)
                            .padding(.top, 16)

                        ForEach(monthRentals) { rental in
                        NavigationLink(destination: RentalDetailView(rental: rental)) {
                            RentalCalendarRow(rental: rental)
                                .padding(.horizontal)
                                .padding(.vertical, 8)
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            Button(role: .destructive) {
                                rentalToDelete = rental
                                showDeleteConfirmation = true
                            } label: {
                                Label(L10n.delete, systemImage: "trash")
                            }
                        }
                    }
                    }
                }
            }
            .confirmationDialog(L10n.delete, isPresented: $showDeleteConfirmation, presenting: rentalToDelete) { rental in
                Button(L10n.delete, role: .destructive) {
                    deleteRentalYearly(rental)
                }
            } message: { _ in
                Text(L10n.deleteRentalConfirm)
            }
        }
    }

    private func deleteRentalYearly(_ rental: Rental) {
        if rental.status == .active {
            rental.car?.status = .free
        }
        modelContext.delete(rental)
    }

    private var rentalsForSelectedMonth: [Rental] {
        guard let range = calendar.range(of: .day, in: .month, for: selectedDate) else { return [] }
        let monthStart = calendar.startOfDay(for: calendar.date(from: calendar.dateComponents([.year, .month], from: selectedDate)) ?? selectedDate)
        guard let monthEnd = calendar.date(byAdding: .day, value: range.count - 1, to: monthStart) else { return [] }
        return rentals.filter { rental in
            let start = calendar.startOfDay(for: rental.pickupDate)
            let end = calendar.startOfDay(for: rental.returnDate)
            return end >= monthStart && start <= monthEnd && rental.status != .cancelled
        }
    }

    private func moveYear(_ direction: Int) {
        if let newDate = calendar.date(byAdding: .year, value: direction, to: selectedDate) {
            selectedDate = newDate
        }
    }
}

struct RentalCalendarRow: View {
    @Environment(CurrencyManager.self) private var currencyManager
    let rental: Rental

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(rental.status.color)
                .frame(width: 10, height: 10)
            VStack(alignment: .leading, spacing: 2) {
                Text(rental.car?.displayName ?? "-")
                    .font(.subheadline.weight(.medium))
                Text(rental.client?.fullName ?? "-")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Text(rental.totalPrice, format: .currency(code: currencyManager.currencyCode))
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.orange)
        }
    }
}
