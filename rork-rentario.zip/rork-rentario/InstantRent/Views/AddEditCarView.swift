import SwiftUI
import SwiftData
import PhotosUI

struct AddEditCarView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Environment(CurrencyManager.self) private var currencyManager
    var car: Car?

    @State private var make: String = ""
    @State private var model: String = ""
    @State private var year: Int = Calendar.current.component(.year, from: Date())
    @State private var licensePlate: String = ""
    @State private var color: String = ""
    @State private var photoURL: String = ""
    @State private var selectedCarColor: CarColor = .black
    @State private var status: CarStatus = .free
    @State private var odometer: Int = 0
    @State private var transmission: TransmissionType = .manual
    @State private var fuelType: FuelType = .gasoline
    @State private var doors: Int = 4
    @State private var seats: Int = 5
    @State private var dailyRate: Double = 0
    @State private var features: [String] = []
    @State private var newFeature: String = ""
    @State private var lastMaintenanceDate: Date? = nil
    @State private var insuranceExpiryDate: Date? = nil
    @State private var hasMaintenanceDate: Bool = false
    @State private var hasInsuranceDate: Bool = false
    @State private var maintenanceDateValue: Date = Date()
    @State private var insuranceDateValue: Date = Date()

    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var selectedImageData: Data? = nil
    @State private var didRemovePhoto: Bool = false

    private var isEditing: Bool { car != nil }

    private var previewImage: UIImage? {
        if didRemovePhoto { return nil }
        if let data = selectedImageData {
            return UIImage(data: data)
        }
        if let car, let data = car.imageData {
            return UIImage(data: data)
        }
        return nil
    }

    var body: some View {
        NavigationStack {
            Form {
                carImageSection
                generalInfoSection
                colorSection
                statusSection
                specsSection
                maintenanceInsuranceSection
                pricingSection
                featuresSection
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle(isEditing ? L10n.editCar : L10n.addCar)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.cancel) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(L10n.save) { saveCar() }
                        .disabled(make.isEmpty || model.isEmpty || licensePlate.isEmpty)
                        .fontWeight(.semibold)
                }
            }
            .onAppear { loadCarData() }
            .onChange(of: selectedPhotoItem) { _, newItem in
                Task {
                    if let data = try? await newItem?.loadTransferable(type: Data.self) {
                        selectedImageData = data
                        didRemovePhoto = false
                    }
                }
            }
        }
    }

    private var carImageSection: some View {
        Section {
            VStack(spacing: 12) {
                if let image = previewImage {
                    Color(.secondarySystemBackground)
                        .frame(height: 180)
                        .overlay {
                            Image(uiImage: image)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .allowsHitTesting(false)
                        }
                        .clipShape(.rect(cornerRadius: 12))
                } else {
                    VStack(spacing: 8) {
                        Image(systemName: "photo.on.rectangle.angled")
                            .font(.system(size: 36))
                            .foregroundStyle(.tertiary)
                        Text(L10n.noPhoto)
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                    .frame(height: 140)
                    .frame(maxWidth: .infinity)
                    .background(Color(.tertiarySystemFill))
                    .clipShape(.rect(cornerRadius: 12))
                }

                HStack(spacing: 12) {
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        Label(L10n.choosePhoto, systemImage: "photo.on.rectangle")
                            .font(.subheadline.weight(.medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(Color.orange.opacity(0.12))
                            .foregroundStyle(.orange)
                            .clipShape(.rect(cornerRadius: 8))
                    }

                    if previewImage != nil {
                        Button {
                            selectedImageData = nil
                            selectedPhotoItem = nil
                            didRemovePhoto = true
                        } label: {
                            Label(L10n.remove, systemImage: "trash")
                                .font(.subheadline.weight(.medium))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(Color.red.opacity(0.12))
                                .foregroundStyle(.red)
                                .clipShape(.rect(cornerRadius: 8))
                        }
                    }
                }
            }
            .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
        } header: {
            Text(L10n.carPhoto)
        } footer: {
            Text(L10n.carPhotoFooter)
        }
    }

    private var generalInfoSection: some View {
        Section(L10n.generalInfo) {
            TextField(L10n.make, text: $make)
            TextField(L10n.model, text: $model)
            Stepper(value: $year, in: 1990...(Calendar.current.component(.year, from: Date()) + 1)) {
                HStack {
                    Text(L10n.year)
                    Spacer()
                    Text("\(year)")
                        .foregroundStyle(.secondary)
                }
            }
            TextField(L10n.licensePlate, text: $licensePlate)
                .textInputAutocapitalization(.characters)
        }
    }

    private var colorSection: some View {
        Section(L10n.color) {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 44), spacing: 4)], spacing: 4) {
                ForEach(CarColor.allCases, id: \.self) { carColor in
                    Button {
                        selectedCarColor = carColor
                    } label: {
                        ZStack {
                            Circle()
                                .fill(carColor.swiftUIColor)
                                .frame(width: 32, height: 32)
                                .overlay {
                                    Circle()
                                        .strokeBorder(carColor == .white ? Color(.systemGray3) : .clear, lineWidth: 1)
                                }

                            if selectedCarColor == carColor {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(carColor == .white || carColor == .yellow || carColor == .beige ? .black : .white)
                            }
                        }
                        .frame(width: 44, height: 44)
                        .contentShape(Circle())
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.vertical, 4)

            HStack {
                Text(L10n.selected)
                    .foregroundStyle(.secondary)
                Spacer()
                HStack(spacing: 6) {
                    Circle()
                        .fill(selectedCarColor.swiftUIColor)
                        .frame(width: 14, height: 14)
                        .overlay {
                            Circle()
                                .strokeBorder(selectedCarColor == .white ? Color(.systemGray3) : .clear, lineWidth: 0.5)
                        }
                    Text(selectedCarColor.displayName)
                        .font(.subheadline.weight(.medium))
                }
            }
        }
    }

    private var statusSection: some View {
        Section(L10n.statusLabel) {
            Picker(L10n.statusLabel, selection: $status) {
                ForEach(CarStatus.allCases, id: \.self) { s in
                    Text(s.displayName).tag(s)
                }
            }
            HStack {
                Text(L10n.odometer)
                Spacer()
                TextField("0", value: $odometer, format: .number)
                    .keyboardType(.numberPad)
                    .multilineTextAlignment(.trailing)
                    .frame(width: 100)
                Text("km")
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var specsSection: some View {
        Section(L10n.vehicleSpecs) {
            Picker(L10n.transmission, selection: $transmission) {
                ForEach(TransmissionType.allCases, id: \.self) { t in
                    Text(t.displayName).tag(t)
                }
            }
            Picker(L10n.fuelType, selection: $fuelType) {
                ForEach(FuelType.allCases, id: \.self) { f in
                    Text(f.displayName).tag(f)
                }
            }
            Stepper(value: $doors, in: 2...6) {
                HStack {
                    Text(L10n.doors)
                    Spacer()
                    Text("\(doors)")
                        .foregroundStyle(.secondary)
                }
            }
            Stepper(value: $seats, in: 1...12) {
                HStack {
                    Text(L10n.seats)
                    Spacer()
                    Text("\(seats)")
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var maintenanceInsuranceSection: some View {
        Section {
            Toggle(L10n.lastMaintenanceDate, isOn: $hasMaintenanceDate.animation())
            if hasMaintenanceDate {
                DatePicker(L10n.dateLabel, selection: $maintenanceDateValue, displayedComponents: .date)
            }

            Toggle(L10n.insuranceExpiryDate, isOn: $hasInsuranceDate.animation())
            if hasInsuranceDate {
                DatePicker(L10n.expiryDate, selection: $insuranceDateValue, displayedComponents: .date)
            }
        } header: {
            Text(L10n.maintenanceAndInsurance)
        } footer: {
            if hasInsuranceDate {
                Text(L10n.insuranceWarningFooter)
            }
        }
    }

    private var pricingSection: some View {
        Section(L10n.pricing) {
            HStack {
                Text(L10n.dailyRate)
                Spacer()
                TextField("0", value: $dailyRate, format: .currency(code: currencyManager.currencyCode))
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .frame(width: 120)
            }
        }
    }

    private var featuresSection: some View {
        Section(L10n.features) {
            ForEach(features, id: \.self) { feature in
                Text(feature)
            }
            .onDelete { offsets in
                features.remove(atOffsets: offsets)
            }
            HStack {
                TextField(L10n.newFeature, text: $newFeature)
                Button(action: addFeature) {
                    Image(systemName: "plus.circle.fill")
                        .foregroundStyle(.orange)
                }
                .disabled(newFeature.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }

    private func loadCarData() {
        guard let car else { return }
        make = car.make
        model = car.model
        year = car.year
        licensePlate = car.licensePlate
        color = car.color
        photoURL = car.photoURL
        selectedCarColor = car.carColor
        status = car.status
        odometer = car.odometer
        transmission = car.transmission
        fuelType = car.fuelType
        doors = car.doors
        seats = car.seats
        dailyRate = car.dailyRate
        features = car.features

        if let date = car.lastMaintenanceDate {
            hasMaintenanceDate = true
            maintenanceDateValue = date
        }
        if let date = car.insuranceExpiryDate {
            hasInsuranceDate = true
            insuranceDateValue = date
        }
    }

    private func addFeature() {
        let trimmed = newFeature.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return }
        features.append(trimmed)
        newFeature = ""
    }

    private func saveCar() {
        let imageDataToSave: Data? = didRemovePhoto ? nil : (selectedImageData ?? car?.imageData)
        let maintenanceDate: Date? = hasMaintenanceDate ? maintenanceDateValue : nil
        let insuranceDate: Date? = hasInsuranceDate ? insuranceDateValue : nil

        if let car {
            car.make = make
            car.model = model
            car.year = year
            car.licensePlate = licensePlate
            car.color = selectedCarColor.displayName
            car.photoURL = photoURL
            car.imageData = imageDataToSave
            car.carColor = selectedCarColor
            car.status = status
            car.odometer = odometer
            car.transmission = transmission
            car.fuelType = fuelType
            car.doors = doors
            car.seats = seats
            car.dailyRate = dailyRate
            car.features = features
            car.lastMaintenanceDate = maintenanceDate
            car.insuranceExpiryDate = insuranceDate
        } else {
            let newCar = Car(
                make: make,
                model: model,
                year: year,
                licensePlate: licensePlate,
                color: selectedCarColor.displayName,
                photoURL: photoURL,
                imageData: imageDataToSave,
                status: status,
                odometer: odometer,
                transmission: transmission,
                fuelType: fuelType,
                carColor: selectedCarColor,
                doors: doors,
                seats: seats,
                features: features,
                dailyRate: dailyRate,
                lastMaintenanceDate: maintenanceDate,
                insuranceExpiryDate: insuranceDate
            )
            modelContext.insert(newCar)
        }
        dismiss()
    }
}
