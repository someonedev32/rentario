import SwiftUI
import SwiftData

struct CarsListView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(SubscriptionService.self) private var subscriptionService
    @Query(sort: \Car.make) private var cars: [Car]
    @State private var searchText: String = ""
    @State private var selectedStatus: CarStatus? = nil
    @State private var showAddCar: Bool = false
    @State private var showPaywall: Bool = false

    private var filteredCars: [Car] {
        var result = cars
        if let status = selectedStatus {
            result = result.filter { $0.status == status }
        }
        if !searchText.isEmpty {
            result = result.filter {
                $0.make.localizedStandardContains(searchText) ||
                $0.model.localizedStandardContains(searchText) ||
                $0.licensePlate.localizedStandardContains(searchText)
            }
        }
        return result
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                statusFilterBar
                    .padding(.vertical, 8)

                List {
                    ForEach(filteredCars) { car in
                        NavigationLink(destination: CarDetailView(car: car)) {
                            CarRowView(car: car)
                        }
                    }
                    .onDelete(perform: deleteCars)
                }
                .listStyle(.plain)
                .overlay {
                    if filteredCars.isEmpty {
                        ContentUnavailableView(L10n.noCars, systemImage: "car.fill", description: Text(L10n.addFirstCar))
                    }
                }
            }
            .background(Color.appBackground)
            .navigationTitle(L10n.cars)
            .searchable(text: $searchText, prompt: Text(L10n.search))
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button(action: {
                        if subscriptionService.isProUser { showAddCar = true } else { showPaywall = true }
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showAddCar) {
                AddEditCarView()
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
        }
    }

    private var statusFilterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                FilterChip(title: L10n.allStatuses, isSelected: selectedStatus == nil) {
                    selectedStatus = nil
                }
                ForEach(CarStatus.allCases, id: \.self) { status in
                    FilterChip(title: status.displayName, isSelected: selectedStatus == status, color: status.color) {
                        selectedStatus = status
                    }
                }
            }
        }
        .contentMargins(.horizontal, 16)
    }

    private func deleteCars(at offsets: IndexSet) {
        for index in offsets {
            let car = filteredCars[index]
            let hasActiveRentals = car.rentals.contains { $0.status == .active }
            guard !hasActiveRentals else { continue }
            modelContext.delete(car)
        }
    }
}

struct FilterChip: View {
    let title: String
    let isSelected: Bool
    var color: Color = .orange
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption.weight(.medium))
                .padding(.horizontal, 14)
                .padding(.vertical, 7)
                .background(isSelected ? color.opacity(0.15) : Color(.tertiarySystemFill))
                .foregroundStyle(isSelected ? color : .secondary)
                .clipShape(.capsule)
        }
        .sensoryFeedback(.selection, trigger: isSelected)
    }
}

struct CarRowView: View {
    @Environment(CurrencyManager.self) private var currencyManager
    let car: Car

    var body: some View {
        HStack(spacing: 14) {
            if let data = car.imageData, let uiImage = UIImage(data: data) {
                Color(.secondarySystemBackground)
                    .frame(width: 48, height: 48)
                    .overlay {
                        Image(uiImage: uiImage)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .allowsHitTesting(false)
                    }
                    .clipShape(.rect(cornerRadius: 12))
            } else {
                Image(systemName: "car.fill")
                    .font(.title3)
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(car.carColor.swiftUIColor.gradient)
                    .clipShape(.rect(cornerRadius: 12))
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(car.displayName)
                        .font(.subheadline.weight(.semibold))
                    if car.isInsuranceExpired || car.isInsuranceExpiringSoon {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.caption2)
                            .foregroundStyle(car.isInsuranceExpired ? .red : .yellow)
                    }
                }
                HStack(spacing: 6) {
                    Text(car.licensePlate)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text("·")
                        .foregroundStyle(.tertiary)
                    Circle()
                        .fill(car.carColor.swiftUIColor)
                        .frame(width: 8, height: 8)
                        .overlay {
                            Circle()
                                .strokeBorder(car.carColor == .white ? Color(.systemGray3) : .clear, lineWidth: 0.5)
                        }
                    Text(car.carColor.displayName)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(car.status.displayName)
                    .font(.caption2.weight(.semibold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(car.status.color.opacity(0.15))
                    .foregroundStyle(car.status.color)
                    .clipShape(.capsule)
                Text(car.dailyRate, format: .currency(code: currencyManager.currencyCode))
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
        .padding(.vertical, 4)
    }
}
