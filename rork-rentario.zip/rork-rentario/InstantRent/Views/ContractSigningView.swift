import SwiftUI
import SwiftData

struct ContractSigningView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(CurrencyManager.self) private var currencyManager
    let rental: Rental
    @Query private var templates: [ContractTemplate]
    @State private var signatureImage: UIImage?
    @State private var showSignaturePad: Bool = false
    @State private var pdfURL: URL?
    @State private var showError: Bool = false
    @State private var isGenerating: Bool = false
    @State private var contractText: String = ""
    @State private var isEditing: Bool = false
    @State private var contractGenerated: Bool = false
    @Environment(\.modelContext) private var modelContext

    private var templateContent: String {
        if let existing = templates.first(where: { $0.isDefault }) ?? templates.first {
            return existing.content
        }
        return ContractTemplate.defaultContent
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    if contractGenerated {
                        contractSuccessView
                    } else {
                        contractPreview
                        signatureSection
                        if isGenerating {
                            ProgressView("Generating contract...")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 20)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            .scrollDismissesKeyboard(.interactively)
            .background(Color.appBackground)
            .navigationTitle(L10n.contract)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(contractGenerated ? L10n.done : L10n.close) { dismiss() }
                }
                if !contractGenerated {
                    ToolbarItem(placement: .primaryAction) {
                        Button(isEditing ? L10n.doneEditing : L10n.editContract) {
                            isEditing.toggle()
                        }
                        .font(.subheadline.weight(.medium))
                    }
                }
            }
            .sheet(isPresented: $showSignaturePad) {
                SignaturePadView(signatureImage: $signatureImage)
            }
            .onChange(of: signatureImage) { _, newValue in
                if newValue != nil && !contractGenerated {
                    generatePDF()
                }
            }
            .alert("PDF Generation Failed", isPresented: $showError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Could not generate the contract PDF. Please try again.")
            }
            .onAppear {
                contractText = PDFService.resolveTemplate(templateContent, rental: rental, currencyCode: currencyManager.currencyCode)
            }
        }
    }

    private var contractPreview: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(L10n.previewContract)
                    .font(.headline)
                Spacer()
                if isEditing {
                    Button(L10n.resetContract) {
                        contractText = PDFService.resolveTemplate(templateContent, rental: rental, currencyCode: currencyManager.currencyCode)
                    }
                    .font(.caption)
                    .foregroundStyle(.orange)
                }
            }

            if isEditing {
                TextEditor(text: $contractText)
                    .font(.system(.caption, design: .monospaced))
                    .frame(minHeight: 400)
                    .padding(4)
                    .background(Color(.secondarySystemGroupedBackground))
                    .clipShape(.rect(cornerRadius: 10))
            } else {
                Text(contractText)
                    .font(.system(.caption, design: .monospaced))
                    .padding(12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(.secondarySystemGroupedBackground))
                    .clipShape(.rect(cornerRadius: 10))
            }
        }
    }

    private var signatureSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L10n.signature)
                .font(.headline)

            if let signatureImage {
                Image(uiImage: signatureImage)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 100)
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .clipShape(.rect(cornerRadius: 10))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(.separator), lineWidth: 1)
                    )

                Button(action: { self.signatureImage = nil }) {
                    Label(L10n.clearSignature, systemImage: "xmark.circle")
                }
                .font(.subheadline)
            }

            Button(action: { showSignaturePad = true }) {
                Label(signatureImage == nil ? L10n.signContract : L10n.reSign, systemImage: "pencil.tip")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
        }
    }

    private var contractSuccessView: some View {
        VStack(spacing: 24) {
            Spacer().frame(height: 40)

            Image(systemName: "checkmark.seal.fill")
                .font(.system(size: 64))
                .foregroundStyle(.green)
                .symbolEffect(.bounce, value: contractGenerated)

            VStack(spacing: 8) {
                Text(L10n.contractReady)
                    .font(.title2.weight(.bold))
                Text(L10n.contractReadySubtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(spacing: 12) {
                Button(action: sharePDF) {
                    Label(L10n.shareContract, systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 4)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)

                Button(action: printPDF) {
                    Label(L10n.printContract, systemImage: "printer")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 4)
                }
                .buttonStyle(.bordered)

                Button(action: {
                    contractGenerated = false
                    signatureImage = nil
                }) {
                    Label(L10n.reSign, systemImage: "arrow.counterclockwise")
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 4)
                }
                .buttonStyle(.bordered)
                .tint(.secondary)
            }
            .padding(.top, 8)
        }
    }

    private func generatePDF() {
        isGenerating = true

        if let sigImage = signatureImage {
            _ = ImageStorageService.saveSignature(sigImage, rentalId: rental.id)
        }

        if let url = PDFService.generateContractPDF(rental: rental, resolvedContent: contractText, signatureImage: signatureImage) {
            let relativePath = "contracts/contract_\(rental.id.uuidString).pdf"
            rental.contractPDFPath = relativePath
            rental.signatureImagePath = "signatures/\(rental.id.uuidString).jpg"
            pdfURL = url
            isGenerating = false
            withAnimation(.spring(duration: 0.4)) {
                contractGenerated = true
            }

        } else {
            isGenerating = false
            showError = true
        }
    }

    private func sharePDF() {
        guard let url = pdfURL else { return }
        let activityVC = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let rootVC = windowScene.keyWindow?.rootViewController {
            var topVC = rootVC
            while let presented = topVC.presentedViewController {
                topVC = presented
            }
            activityVC.popoverPresentationController?.sourceView = topVC.view
            topVC.present(activityVC, animated: true)
        }
    }

    private func printPDF() {
        guard let url = pdfURL else { return }
        let printController = UIPrintInteractionController.shared
        printController.printingItem = url
        printController.present(animated: true)
    }
}
