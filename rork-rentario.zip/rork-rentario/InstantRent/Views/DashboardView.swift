import SwiftUI
import SwiftData

struct DashboardView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(SubscriptionService.self) private var subscriptionService
    @Environment(CurrencyManager.self) private var currencyManager
    @Query(filter: #Predicate<Rental> { $0.statusRaw == "active" }, sort: \Rental.pickupDate) private var activeRentals: [Rental]
    @Query(filter: #Predicate<Car> { $0.statusRaw == "free" }) private var freeCars: [Car]
    @Query(filter: #Predicate<Car> { $0.statusRaw == "maintenance" }) private var maintenanceCars: [Car]
    @Query private var allCars: [Car]
    @Query private var allRentals: [Rental]
    @Query private var allClients: [Client]
    @State private var showNewRental: Bool = false
    @State private var showAddCar: Bool = false
    @State private var showAddClient: Bool = false
    @State private var showRentalsList: Bool = false
    @State private var showPaywall: Bool = false

    private var upcomingReturns: [Rental] {
        let tomorrow = Calendar.current.date(byAdding: .day, value: 2, to: Date().startOfDay) ?? Date()
        return activeRentals.filter { $0.returnDate <= tomorrow }
    }

    private func revenueDate(for rental: Rental) -> Date {
        rental.actualReturnDate ?? rental.returnDate
    }

    private var weekRevenue: Double {
        let weekStart = Date().startOfWeek
        return allRentals.filter { $0.status == .completed && revenueDate(for: $0) >= weekStart }.reduce(0) { $0 + $1.totalPrice }
    }

    private var monthRevenue: Double {
        let monthStart = Date().startOfMonth
        return allRentals.filter { $0.status == .completed && revenueDate(for: $0) >= monthStart }.reduce(0) { $0 + $1.totalPrice }
    }

    private var lastMonthRevenue: Double {
        let calendar = Calendar.current
        let thisMonthStart = Date().startOfMonth
        guard let lastMonthStart = calendar.date(byAdding: .month, value: -1, to: thisMonthStart) else { return 0 }
        return allRentals.filter {
            $0.status == .completed &&
            revenueDate(for: $0) >= lastMonthStart &&
            revenueDate(for: $0) < thisMonthStart
        }.reduce(0) { $0 + $1.totalPrice }
    }

    private var monthChange: Double? {
        guard lastMonthRevenue > 0 else { return nil }
        return ((monthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    statsSection
                    quickActionsSection
                    revenueSection
                    todayRentalsSection
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            .background(Color.appBackground)
            .navigationTitle(L10n.dashboard)
            .sheet(isPresented: $showNewRental) {
                NewRentalView()
            }
            .sheet(isPresented: $showAddCar) {
                AddEditCarView()
            }
            .sheet(isPresented: $showAddClient) {
                AddEditClientView()
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
            .navigationDestination(isPresented: $showRentalsList) {
                RentalsListView()
            }
        }
    }

    private var statsSection: some View {
        let columns = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]
        return LazyVGrid(columns: columns, spacing: 12) {
            StatCard(
                title: L10n.activeRentals,
                value: "\(activeRentals.count)",
                icon: "clock.fill",
                color: .orange
            )
            StatCard(
                title: L10n.availableCars,
                value: "\(freeCars.count)",
                icon: "car.fill",
                color: .green
            )
            StatCard(
                title: L10n.upcomingReturns,
                value: "\(upcomingReturns.count)",
                icon: "arrow.uturn.left.circle.fill",
                color: .blue
            )
            StatCard(
                title: L10n.inMaintenance,
                value: "\(maintenanceCars.count)",
                icon: "wrench.and.screwdriver.fill",
                color: .red
            )
        }
        .padding(.top, 8)
    }

    private var quickActionsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L10n.quickActions)
                .font(.headline)
            HStack(spacing: 12) {
                QuickActionButton(title: L10n.newRental, icon: "plus.circle.fill", color: .orange) {
                    if subscriptionService.isProUser { showNewRental = true } else { showPaywall = true }
                }
                QuickActionButton(title: L10n.addCar, icon: "car.badge.gearshape.fill", color: .blue) {
                    if subscriptionService.isProUser { showAddCar = true } else { showPaywall = true }
                }
                QuickActionButton(title: L10n.addClient, icon: "person.badge.plus", color: .green) {
                    if subscriptionService.isProUser { showAddClient = true } else { showPaywall = true }
                }
            }
        }
    }

    private var revenueSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L10n.revenue)
                .font(.headline)
            HStack(spacing: 8) {
                RevenueCard(title: L10n.thisWeek, amount: weekRevenue, currencyCode: currencyManager.currencyCode)
                RevenueCard(title: L10n.thisMonth, amount: monthRevenue, currencyCode: currencyManager.currencyCode)
                RevenueComparisonCard(current: monthRevenue, previous: lastMonthRevenue, changePercent: monthChange, currencyCode: currencyManager.currencyCode)
            }
            .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var todayRentalsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(L10n.activeRentals)
                    .font(.headline)
                Spacer()
                if !activeRentals.isEmpty {
                    Button(action: { showRentalsList = true }) {
                        Text(L10n.seeAll)
                            .font(.subheadline)
                    }
                }
            }
            if activeRentals.isEmpty {
                ContentUnavailableView(L10n.noRentals, systemImage: "car.fill", description: Text(L10n.noActiveRentalsDesc))
                    .frame(height: 200)
            } else {
                ForEach(activeRentals.prefix(5)) { rental in
                    NavigationLink(destination: RentalDetailView(rental: rental)) {
                        RentalRowCard(rental: rental)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(color)
            Text(value)
                .font(.title.bold())
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .background(Color.cardBackground)
        .clipShape(.rect(cornerRadius: 14))
    }
}

struct QuickActionButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(color)
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.cardBackground)
            .clipShape(.rect(cornerRadius: 12))
        }
    }
}

struct RevenueCard: View {
    let title: String
    let amount: Double
    let currencyCode: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
            Text(amount, format: .currency(code: currencyCode))
                .font(.subheadline.bold())
                .foregroundStyle(.orange)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .padding(10)
        .background(Color.cardBackground)
        .clipShape(.rect(cornerRadius: 12))
    }
}

struct RevenueComparisonCard: View {
    let current: Double
    let previous: Double
    let changePercent: Double?
    let currencyCode: String

    private var isPositive: Bool {
        (changePercent ?? 0) >= 0
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(L10n.vsLastMonth)
                .font(.caption)
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
            if let change = changePercent {
                HStack(spacing: 2) {
                    Image(systemName: isPositive ? "arrow.up.right" : "arrow.down.right")
                        .font(.caption2.bold())
                    Text("\(abs(change), specifier: "%.1f")%")
                        .font(.subheadline.bold())
                }
                .foregroundStyle(isPositive ? .green : .red)
            } else {
                let diff = current - previous
                let diffIsPositive = diff >= 0
                HStack(spacing: 2) {
                    Image(systemName: diffIsPositive ? "arrow.up.right" : "arrow.down.right")
                        .font(.caption2.bold())
                    Text(diff, format: .currency(code: currencyCode))
                        .font(.subheadline.bold())
                }
                .foregroundStyle(diff == 0 ? Color.secondary : (diffIsPositive ? Color.green : Color.red))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .padding(10)
        .background(Color.cardBackground)
        .clipShape(.rect(cornerRadius: 12))
    }
}

struct RentalRowCard: View {
    let rental: Rental

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "car.fill")
                .font(.title3)
                .foregroundStyle(.orange)
                .frame(width: 44, height: 44)
                .background(Color.orange.opacity(0.12))
                .clipShape(.rect(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 4) {
                Text(rental.car?.displayName ?? "-")
                    .font(.subheadline.weight(.semibold))
                Text(rental.client?.fullName ?? "-")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(rental.returnDate, style: .date)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(rental.status.displayName)
                    .font(.caption2.weight(.semibold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 2)
                    .background(rental.status.color.opacity(0.15))
                    .foregroundStyle(rental.status.color)
                    .clipShape(.capsule)
            }
        }
        .padding(12)
        .background(Color.cardBackground)
        .clipShape(.rect(cornerRadius: 12))
    }
}
