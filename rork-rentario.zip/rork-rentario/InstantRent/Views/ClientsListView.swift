import SwiftUI
import SwiftData

struct ClientsListView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(SubscriptionService.self) private var subscriptionService
    @Query(sort: \Client.fullName) private var clients: [Client]
    @State private var searchText: String = ""
    @State private var showAddClient: Bool = false
    @State private var showPaywall: Bool = false

    private var filteredClients: [Client] {
        guard !searchText.isEmpty else { return clients }
        return clients.filter {
            $0.fullName.localizedStandardContains(searchText) ||
            $0.phone.localizedStandardContains(searchText) ||
            $0.email.localizedStandardContains(searchText)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(filteredClients) { client in
                    NavigationLink(destination: ClientDetailView(client: client)) {
                        ClientRowView(client: client)
                    }
                }
                .onDelete(perform: deleteClients)
            }
            .listStyle(.plain)
            .overlay {
                if filteredClients.isEmpty {
                    ContentUnavailableView(L10n.noClients, systemImage: "person.2.fill", description: Text(L10n.addFirstClient))
                }
            }
            .background(Color.appBackground)
            .navigationTitle(L10n.clients)
            .searchable(text: $searchText, prompt: Text(L10n.search))
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button(action: {
                        if subscriptionService.isProUser { showAddClient = true } else { showPaywall = true }
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showAddClient) {
                AddEditClientView()
            }
            .sheet(isPresented: $showPaywall) {
                PaywallView()
            }
        }
    }

    private func deleteClients(at offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(filteredClients[index])
        }
    }
}

struct ClientRowView: View {
    let client: Client

    var body: some View {
        HStack(spacing: 14) {
            Text(client.fullName.prefix(2).uppercased())
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
                .background(Color.orange.gradient)
                .clipShape(Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(client.fullName)
                    .font(.subheadline.weight(.semibold))
                if !client.phone.isEmpty {
                    HStack(spacing: 4) {
                        Image(systemName: "phone.fill")
                            .font(.caption2)
                        Text(client.phone)
                            .font(.caption)
                    }
                    .foregroundStyle(.secondary)
                }
            }

            Spacer()

            if !client.rentals.isEmpty {
                Text("\(client.rentals.count)")
                    .font(.caption.weight(.medium))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(Color.orange.opacity(0.12))
                    .foregroundStyle(.orange)
                    .clipShape(.capsule)
            }
        }
        .padding(.vertical, 4)
    }
}
