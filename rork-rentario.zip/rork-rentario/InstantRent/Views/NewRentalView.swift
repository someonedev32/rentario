import SwiftUI
import SwiftData

struct NewRentalView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Environment(CurrencyManager.self) private var currencyManager
    @Query(filter: #Predicate<Car> { $0.statusRaw == "free" }, sort: \Car.make) private var availableCars: [Car]
    @Query(sort: \Client.fullName) private var allClients: [Client]

    @State private var currentStep: Int = 0
    @State private var selectedCar: Car?
    @State private var selectedClient: Client?
    @State private var pickupDate: Date = Date()
    @State private var returnDate: Date = Date().addingTimeInterval(86400)
    @State private var pickupLocation: String = ""
    @State private var dropoffLocation: String = ""
    @State private var kmAtPickup: Int = 0
    @State private var dailyRate: Double = 0
    @State private var extras: [RentalExtra] = []
    @State private var discountType: String = "none"
    @State private var discountValue: Double = 0
    @State private var notes: String = ""

    private var numberOfDays: Int {
        let days = Calendar.current.dateComponents([.day], from: pickupDate, to: returnDate).day ?? 1
        return max(days, 1)
    }

    private var totalPrice: Double {
        PricingEngine.calculateTotal(
            dailyRate: dailyRate,
            numberOfDays: numberOfDays,
            extras: extras,
            discountType: discountType,
            discountValue: discountValue
        )
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                stepIndicator
                    .padding(.vertical, 12)

                TabView(selection: $currentStep) {
                    selectCarStep.tag(0)
                    selectClientStep.tag(1)
                    detailsStep.tag(2)
                    reviewStep.tag(3)
                }
                .tabViewStyle(.page(indexDisplayMode: .never))
                .animation(.easeInOut, value: currentStep)

                bottomBar
            }
            .background(Color.appBackground)
            .navigationTitle(L10n.newRental)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.cancel) { dismiss() }
                }
            }
        }
    }

    private var stepIndicator: some View {
        HStack(spacing: 8) {
            ForEach(0..<4) { step in
                Capsule()
                    .fill(step <= currentStep ? Color.orange : Color(.tertiarySystemFill))
                    .frame(height: 4)
            }
        }
        .padding(.horizontal)
    }

    private var bottomBar: some View {
        VStack(spacing: 12) {
            if currentStep < 3 {
                Button {
                    withAnimation { currentStep += 1 }
                } label: {
                    Text(L10n.next)
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
                .clipShape(.rect(cornerRadius: 14))
                .disabled(!canAdvance)
            } else {
                Button {
                    createRental()
                } label: {
                    Text(L10n.createRental)
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                }
                .buttonStyle(.borderedProminent)
                .tint(.orange)
                .clipShape(.rect(cornerRadius: 14))
                .disabled(selectedCar == nil || selectedClient == nil)
            }

            if currentStep > 0 {
                Button {
                    withAnimation { currentStep -= 1 }
                } label: {
                    Text(L10n.previous)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal)
        .padding(.top, 12)
        .padding(.bottom, 8)
        .background(.bar)
    }

    private var canAdvance: Bool {
        switch currentStep {
        case 0: return selectedCar != nil
        case 1: return selectedClient != nil
        case 2: return true
        default: return true
        }
    }

    private var selectCarStep: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L10n.selectCar)
                .font(.title3.bold())
                .padding(.horizontal)

            if availableCars.isEmpty {
                ContentUnavailableView(L10n.noCars, systemImage: "car.fill", description: Text(L10n.noFreeCars))
                    .frame(maxHeight: .infinity)
            } else {
                List(availableCars, selection: Binding(
                    get: { selectedCar?.id },
                    set: { id in selectedCar = availableCars.first(where: { $0.id == id }) }
                )) { car in
                    HStack(spacing: 12) {
                        Image(systemName: "car.fill")
                            .foregroundStyle(.orange)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(car.displayName)
                                .font(.subheadline.weight(.semibold))
                            Text("\(car.licensePlate) · \(car.dailyRate, format: .currency(code: currencyManager.currencyCode))/\(L10n.perDay)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if selectedCar?.id == car.id {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.orange)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedCar = car
                        dailyRate = car.dailyRate
                        kmAtPickup = car.odometer
                    }
                }
                .listStyle(.plain)
            }
        }
    }

    private var selectClientStep: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L10n.selectClient)
                .font(.title3.bold())
                .padding(.horizontal)

            if allClients.isEmpty {
                ContentUnavailableView(L10n.noClients, systemImage: "person.2.fill")
                    .frame(maxHeight: .infinity)
            } else {
                List(allClients) { client in
                    HStack(spacing: 12) {
                        Text(client.fullName.prefix(2).uppercased())
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .frame(width: 36, height: 36)
                            .background(Color.orange.gradient)
                            .clipShape(Circle())
                        VStack(alignment: .leading, spacing: 2) {
                            Text(client.fullName)
                                .font(.subheadline.weight(.semibold))
                            if !client.phone.isEmpty {
                                Text(client.phone)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        if selectedClient?.id == client.id {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundStyle(.orange)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedClient = client
                    }
                }
                .listStyle(.plain)
            }
        }
    }

    private var detailsStep: some View {
        Form {
            Section(L10n.locations) {
                HStack(spacing: 10) {
                    Image(systemName: "mappin.circle.fill")
                        .foregroundStyle(.orange)
                    TextField(L10n.pickupLocationLabel, text: $pickupLocation)
                }
                HStack(spacing: 10) {
                    Image(systemName: "mappin.circle")
                        .foregroundStyle(.secondary)
                    TextField(L10n.dropoffLocationLabel, text: $dropoffLocation)
                }
            }

            Section(L10n.rentalPeriod) {
                DatePicker(L10n.pickupDate, selection: $pickupDate, displayedComponents: [.date, .hourAndMinute])
                DatePicker(L10n.returnDate, selection: $returnDate, in: pickupDate..., displayedComponents: [.date, .hourAndMinute])
            }

            Section(L10n.kmAtPickup) {
                TextField("0", value: $kmAtPickup, format: .number)
                    .keyboardType(.numberPad)
            }

            Section(L10n.pricing) {
                HStack {
                    Text(L10n.dailyRate)
                    Spacer()
                    TextField("0", value: $dailyRate, format: .currency(code: currencyManager.currencyCode))
                        .keyboardType(.decimalPad)
                        .multilineTextAlignment(.trailing)
                        .frame(width: 120)
                }
            }

            Section(L10n.extras) {
                ForEach(Array(extras.enumerated()), id: \.element.id) { index, _ in
                    ExtraRow(extra: $extras[index])
                }
                .onDelete { offsets in
                    extras.remove(atOffsets: offsets)
                }
                Button(action: { extras.append(RentalExtra()) }) {
                    Label(L10n.addExtra, systemImage: "plus.circle.fill")
                }
            }

            Section(L10n.discount) {
                Picker(L10n.discount, selection: $discountType) {
                    Text(L10n.none).tag("none")
                    Text(L10n.percentage).tag("percentage")
                    Text(L10n.fixedAmount).tag("fixed")
                }
                if discountType != "none" {
                    HStack {
                        Text(discountType == "percentage" ? "%" : currencyManager.selected.symbol)
                        TextField("0", value: $discountValue, format: .number)
                            .keyboardType(.decimalPad)
                    }
                }
            }

            Section(L10n.notes) {
                TextField(L10n.notes, text: $notes)
            }
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private var reviewStep: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text(L10n.reviewAndConfirm)
                    .font(.title3.bold())

                DetailSection(title: L10n.carDetails) {
                    Text(selectedCar?.displayName ?? "-")
                        .font(.subheadline.weight(.medium))
                    Text(selectedCar?.licensePlate ?? "-")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                DetailSection(title: L10n.clientDetails) {
                    Text(selectedClient?.fullName ?? "-")
                        .font(.subheadline.weight(.medium))
                }

                if !pickupLocation.isEmpty || !dropoffLocation.isEmpty {
                    DetailSection(title: L10n.locations) {
                        if !pickupLocation.isEmpty {
                            HStack(spacing: 8) {
                                Image(systemName: "mappin.circle.fill")
                                    .foregroundStyle(.orange)
                                    .font(.caption)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(L10n.pickupLocationLabel)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    Text(pickupLocation)
                                        .font(.subheadline.weight(.medium))
                                }
                            }
                        }
                        if !dropoffLocation.isEmpty {
                            HStack(spacing: 8) {
                                Image(systemName: "mappin.circle")
                                    .foregroundStyle(.secondary)
                                    .font(.caption)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(L10n.dropoffLocationLabel)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                    Text(dropoffLocation)
                                        .font(.subheadline.weight(.medium))
                                }
                            }
                        }
                    }
                }

                DetailSection(title: L10n.pricingDetails) {
                    HStack {
                        Text("\(numberOfDays) \(L10n.days) × \(dailyRate, format: .currency(code: currencyManager.currencyCode))")
                        Spacer()
                        Text(dailyRate * Double(numberOfDays), format: .currency(code: currencyManager.currencyCode))
                    }
                    .font(.subheadline)

                    ForEach(extras) { extra in
                        HStack {
                            Text(extra.name)
                            Spacer()
                            let amount = extra.isFlat ? extra.pricePerDay : extra.pricePerDay * Double(numberOfDays)
                            Text(amount, format: .currency(code: currencyManager.currencyCode))
                        }
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    }

                    Divider()

                    HStack {
                        Text(L10n.totalPrice)
                            .font(.headline)
                        Spacer()
                        Text(totalPrice, format: .currency(code: currencyManager.currencyCode))
                            .font(.title3.bold())
                            .foregroundStyle(.orange)
                    }
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
    }

    private func createRental() {
        guard let car = selectedCar, let client = selectedClient else { return }

        let rental = Rental(
            car: car,
            client: client,
            pickupDate: pickupDate,
            returnDate: returnDate,
            status: .active,
            kmAtPickup: kmAtPickup,
            dailyRate: dailyRate,
            extras: extras,
            discountType: discountType,
            discountValue: discountValue,
            totalPrice: totalPrice,
            notes: notes,
            pickupLocation: pickupLocation,
            dropoffLocation: dropoffLocation
        )

        car.status = .rented
        modelContext.insert(rental)
        dismiss()
    }
}

struct ExtraRow: View {
    @Environment(CurrencyManager.self) private var currencyManager
    @Binding var extra: RentalExtra

    var body: some View {
        VStack(spacing: 8) {
            TextField(L10n.extraName, text: $extra.name)
            HStack {
                TextField(L10n.price, value: $extra.pricePerDay, format: .currency(code: currencyManager.currencyCode))
                    .keyboardType(.decimalPad)
                Toggle(L10n.flat, isOn: $extra.isFlat)
                    .labelsHidden()
                Text(extra.isFlat ? L10n.flat : L10n.perDay)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}
