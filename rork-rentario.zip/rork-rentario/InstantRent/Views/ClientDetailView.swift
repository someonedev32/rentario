import SwiftUI
import SwiftData

struct ClientDetailView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Environment(CurrencyManager.self) private var currencyManager
    let client: Client
    @State private var showEdit: Bool = false
    @State private var showDeleteConfirm: Bool = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                headerSection
                contactSection
                notesSection
                documentsSection
                rentalHistorySection
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
        .background(Color.appBackground)
        .navigationTitle(client.fullName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Button(action: { showEdit = true }) {
                        Label(L10n.edit, systemImage: "pencil")
                    }
                    Button(role: .destructive, action: { showDeleteConfirm = true }) {
                        Label(L10n.delete, systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .sheet(isPresented: $showEdit) {
            AddEditClientView(client: client)
        }
        .confirmationDialog(L10n.delete, isPresented: $showDeleteConfirm, titleVisibility: .visible) {
            Button(L10n.delete, role: .destructive) {
                modelContext.delete(client)
                dismiss()
            }
        }
    }

    private var headerSection: some View {
        VStack(spacing: 12) {
            Text(client.fullName.prefix(2).uppercased())
                .font(.title.bold())
                .foregroundStyle(.white)
                .frame(width: 80, height: 80)
                .background(Color.orange.gradient)
                .clipShape(Circle())

            Text(client.fullName)
                .font(.title2.bold())
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
    }

    private var contactSection: some View {
        DetailSection(title: L10n.contactInfo) {
            if !client.phone.isEmpty {
                HStack {
                    Image(systemName: "phone.fill")
                        .foregroundStyle(.orange)
                    Text(client.phone)
                    Spacer()
                    if let url = URL(string: "tel:\(client.phone)") {
                    Link(destination: url) {
                        Image(systemName: "phone.circle.fill")
                            .font(.title3)
                            .foregroundStyle(.green)
                    }
                    }
                }
            }
            if !client.email.isEmpty {
                HStack {
                    Image(systemName: "envelope.fill")
                        .foregroundStyle(.orange)
                    Text(client.email)
                    Spacer()
                    if let url = URL(string: "mailto:\(client.email)") {
                    Link(destination: url) {
                        Image(systemName: "envelope.circle.fill")
                            .font(.title3)
                            .foregroundStyle(.blue)
                    }
                    }
                }
            }
        }
    }

    private var notesSection: some View {
        Group {
            if !client.notes.isEmpty {
                DetailSection(title: L10n.notes) {
                    Text(client.notes)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var documentsSection: some View {
        VStack(spacing: 16) {
            if client.idFrontPath != nil || client.idBackPath != nil {
                DetailSection(title: L10n.idDocuments) {
                    HStack(spacing: 12) {
                        DocumentDetailSlot(label: L10n.front, path: client.idFrontPath)
                        DocumentDetailSlot(label: L10n.back, path: client.idBackPath)
                    }
                }
            }
            if client.licenseFrontPath != nil || client.licenseBackPath != nil {
                DetailSection(title: L10n.driverLicense) {
                    HStack(spacing: 12) {
                        DocumentDetailSlot(label: L10n.front, path: client.licenseFrontPath)
                        DocumentDetailSlot(label: L10n.back, path: client.licenseBackPath)
                    }
                }
            }
        }
    }

    private var rentalHistorySection: some View {
        DetailSection(title: L10n.rentalHistory) {
            if client.rentals.isEmpty {
                Text(L10n.noRentals)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 8)
            } else {
                ForEach(client.rentals.sorted(by: { $0.createdAt > $1.createdAt }).prefix(10)) { rental in
                    NavigationLink(destination: RentalDetailView(rental: rental)) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(rental.car?.displayName ?? "-")
                                    .font(.subheadline)
                                Text(rental.pickupDate, style: .date)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(rental.totalPrice, format: .currency(code: currencyManager.currencyCode))
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.orange)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

struct DocumentDetailSlot: View {
    let label: String
    let path: String?
    @State private var image: UIImage?

    var body: some View {
        VStack(spacing: 6) {
            Text(label)
                .font(.caption.weight(.medium))
                .foregroundStyle(.secondary)

            if let image {
                Color(.secondarySystemBackground)
                    .frame(height: 90)
                    .frame(maxWidth: .infinity)
                    .overlay {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .allowsHitTesting(false)
                    }
                    .clipShape(.rect(cornerRadius: 10))
            } else {
                Color(.tertiarySystemFill)
                    .frame(height: 90)
                    .frame(maxWidth: .infinity)
                    .overlay {
                        Image(systemName: "doc.fill")
                            .foregroundStyle(.secondary)
                    }
                    .clipShape(.rect(cornerRadius: 10))
            }
        }
        .frame(maxWidth: .infinity)
        .onAppear {
            if let path {
                image = ImageStorageService.loadImage(relativePath: path)
            }
        }
    }
}


