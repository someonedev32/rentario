import SwiftUI

struct SignaturePadView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var signatureImage: UIImage?
    @State private var lines: [[CGPoint]] = []
    @State private var currentLine: [CGPoint] = []

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                Text(L10n.signBelow)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                Canvas { context, size in
                    for line in lines {
                        drawLine(context: context, points: line)
                    }
                    drawLine(context: context, points: currentLine)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 250)
                .background(Color.white)
                .clipShape(.rect(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color(.separator), lineWidth: 1)
                )
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            currentLine.append(value.location)
                        }
                        .onEnded { _ in
                            lines.append(currentLine)
                            currentLine = []
                        }
                )

                HStack(spacing: 16) {
                    Button(action: clearSignature) {
                        Label(L10n.clearSignature, systemImage: "xmark.circle")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)

                    Button(action: saveSignature) {
                        Label(L10n.done, systemImage: "checkmark.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.orange)
                    .disabled(lines.isEmpty)
                }
            }
            .padding()
            .navigationTitle(L10n.signature)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.cancel) { dismiss() }
                }
            }
        }
    }

    private func drawLine(context: GraphicsContext, points: [CGPoint]) {
        guard points.count > 1 else { return }
        var path = Path()
        path.move(to: points[0])
        for point in points.dropFirst() {
            path.addLine(to: point)
        }
        context.stroke(path, with: .color(.black), lineWidth: 2.5)
    }

    private func clearSignature() {
        lines = []
        currentLine = []
    }

    private func saveSignature() {
        let renderer = ImageRenderer(content:
            Canvas { context, size in
                for line in lines {
                    drawLine(context: context, points: line)
                }
            }
            .frame(width: 400, height: 250)
            .background(Color.white)
        )
        renderer.scale = 2.0
        if let image = renderer.uiImage {
            signatureImage = image
        }
        dismiss()
    }
}
