import SwiftUI
import SwiftData

struct CarDetailView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @Environment(CurrencyManager.self) private var currencyManager
    let car: Car
    @State private var showEdit: Bool = false
    @State private var showDeleteConfirm: Bool = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                headerSection
                insuranceWarningBanner
                statusSection
                specsSection
                maintenanceInsuranceSection
                featuresSection
                pricingSection
                rentalHistorySection
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
        .background(Color.appBackground)
        .navigationTitle(car.displayName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Button(action: { showEdit = true }) {
                        Label(L10n.edit, systemImage: "pencil")
                    }
                    Button(role: .destructive, action: { showDeleteConfirm = true }) {
                        Label(L10n.delete, systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .sheet(isPresented: $showEdit) {
            AddEditCarView(car: car)
        }
        .confirmationDialog(L10n.delete, isPresented: $showDeleteConfirm, titleVisibility: .visible) {
            Button(L10n.delete, role: .destructive) {
                modelContext.delete(car)
                dismiss()
            }
        }
    }

    private var headerSection: some View {
        VStack(spacing: 12) {
            if let data = car.imageData, let uiImage = UIImage(data: data) {
                Color(.secondarySystemBackground)
                    .frame(height: 200)
                    .overlay {
                        Image(uiImage: uiImage)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .allowsHitTesting(false)
                    }
                    .clipShape(.rect(cornerRadius: 16))
            } else {
                Image(systemName: "car.fill")
                    .font(.system(size: 48))
                    .foregroundStyle(.white)
                    .frame(width: 96, height: 96)
                    .background(car.carColor.swiftUIColor.gradient)
                    .clipShape(.rect(cornerRadius: 24))
            }

            Text(car.displayName)
                .font(.title2.bold())

            HStack(spacing: 8) {
                Text(car.licensePlate)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Circle()
                    .fill(car.carColor.swiftUIColor)
                    .frame(width: 12, height: 12)
                    .overlay {
                        Circle()
                            .strokeBorder(car.carColor == .white ? Color(.systemGray3) : .clear, lineWidth: 0.5)
                    }
                Text(car.carColor.displayName)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
    }

    @ViewBuilder
    private var insuranceWarningBanner: some View {
        if car.isInsuranceExpired {
            HStack(spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundStyle(.white)
                VStack(alignment: .leading, spacing: 2) {
                    Text(L10n.insuranceExpired)
                        .font(.subheadline.bold())
                        .foregroundStyle(.white)
                    if let date = car.insuranceExpiryDate {
                        Text("\(L10n.expiredOn) \(date, format: .dateTime.day().month().year())")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.85))
                    }
                }
                Spacer()
            }
            .padding(14)
            .background(Color.red.gradient)
            .clipShape(.rect(cornerRadius: 12))
        } else if car.isInsuranceExpiringSoon {
            HStack(spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundStyle(.black.opacity(0.7))
                VStack(alignment: .leading, spacing: 2) {
                    Text(L10n.insuranceExpiringSoon)
                        .font(.subheadline.bold())
                        .foregroundStyle(.black.opacity(0.8))
                    if let date = car.insuranceExpiryDate {
                        Text("\(L10n.expiresOn) \(date, format: .dateTime.day().month().year())")
                            .font(.caption)
                            .foregroundStyle(.black.opacity(0.6))
                    }
                }
                Spacer()
            }
            .padding(14)
            .background(Color.yellow.gradient)
            .clipShape(.rect(cornerRadius: 12))
        }
    }

    private var statusSection: some View {
        DetailSection(title: L10n.statusLabel) {
            HStack {
                Image(systemName: car.status.icon)
                    .foregroundStyle(car.status.color)
                Text(car.status.displayName)
                    .font(.body.weight(.medium))
                    .foregroundStyle(car.status.color)
                Spacer()
                Text("\(car.odometer) km")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var specsSection: some View {
        DetailSection(title: L10n.vehicleSpecs) {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                SpecItem(label: L10n.year, value: "\(car.year)")
                SpecItem(label: L10n.color, value: car.carColor.displayName)
                SpecItem(label: L10n.transmission, value: car.transmission.displayName)
                SpecItem(label: L10n.fuelType, value: car.fuelType.displayName)
                SpecItem(label: L10n.doors, value: "\(car.doors)")
                SpecItem(label: L10n.seats, value: "\(car.seats)")
            }
        }
    }

    @ViewBuilder
    private var maintenanceInsuranceSection: some View {
        if car.lastMaintenanceDate != nil || car.insuranceExpiryDate != nil {
            DetailSection(title: L10n.maintenanceAndInsurance) {
                if let maintenanceDate = car.lastMaintenanceDate {
                    HStack {
                        Label(L10n.lastMaintenance, systemImage: "wrench.and.screwdriver")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text(maintenanceDate, format: .dateTime.day().month().year())
                            .font(.subheadline.weight(.medium))
                    }
                }
                if let insuranceDate = car.insuranceExpiryDate {
                    HStack {
                        Label(L10n.insuranceExpiry, systemImage: "shield.checkered")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Spacer()
                        HStack(spacing: 6) {
                            if car.isInsuranceExpired {
                                Image(systemName: "exclamationmark.circle.fill")
                                    .foregroundStyle(.red)
                                    .font(.caption)
                            } else if car.isInsuranceExpiringSoon {
                                Image(systemName: "exclamationmark.circle.fill")
                                    .foregroundStyle(.yellow)
                                    .font(.caption)
                            }
                            Text(insuranceDate, format: .dateTime.day().month().year())
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(car.isInsuranceExpired ? .red : (car.isInsuranceExpiringSoon ? .orange : .primary))
                        }
                    }
                }
            }
        }
    }

    private var featuresSection: some View {
        Group {
            if !car.features.isEmpty {
                DetailSection(title: L10n.features) {
                    FlowLayout(spacing: 8) {
                        ForEach(car.features, id: \.self) { feature in
                            Text(feature)
                                .font(.caption)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(Color.orange.opacity(0.1))
                                .foregroundStyle(.orange)
                                .clipShape(.capsule)
                        }
                    }
                }
            }
        }
    }

    private var pricingSection: some View {
        DetailSection(title: L10n.pricing) {
            HStack {
                Text(L10n.dailyRate)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(car.dailyRate, format: .currency(code: currencyManager.currencyCode))
                    .font(.headline)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var rentalHistorySection: some View {
        DetailSection(title: L10n.rentalHistory) {
            if car.rentals.isEmpty {
                Text(L10n.noRentals)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 8)
            } else {
                ForEach(car.rentals.sorted(by: { $0.createdAt > $1.createdAt }).prefix(10)) { rental in
                    NavigationLink(destination: RentalDetailView(rental: rental)) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(rental.client?.fullName ?? "-")
                                    .font(.subheadline)
                                Text(rental.pickupDate, style: .date)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(rental.status.displayName)
                                .font(.caption2.weight(.semibold))
                                .padding(.horizontal, 8)
                                .padding(.vertical, 3)
                                .background(rental.status.color.opacity(0.15))
                                .foregroundStyle(rental.status.color)
                                .clipShape(.capsule)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

struct DetailSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
            VStack(alignment: .leading, spacing: 10) {
                content
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.cardBackground)
            .clipShape(.rect(cornerRadius: 14))
        }
    }
}

struct SpecItem: View {
    let label: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.subheadline.weight(.medium))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let result = arrangeSubviews(proposal: proposal, subviews: subviews)
        return result.size
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = arrangeSubviews(proposal: proposal, subviews: subviews)
        for (index, position) in result.positions.enumerated() {
            subviews[index].place(at: CGPoint(x: bounds.minX + position.x, y: bounds.minY + position.y), proposal: .unspecified)
        }
    }

    private func arrangeSubviews(proposal: ProposedViewSize, subviews: Subviews) -> (positions: [CGPoint], size: CGSize) {
        let maxWidth = proposal.width ?? .infinity
        var positions: [CGPoint] = []
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0
        var maxX: CGFloat = 0

        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if x + size.width > maxWidth && x > 0 {
                x = 0
                y += rowHeight + spacing
                rowHeight = 0
            }
            positions.append(CGPoint(x: x, y: y))
            rowHeight = max(rowHeight, size.height)
            x += size.width + spacing
            maxX = max(maxX, x)
        }

        return (positions, CGSize(width: maxX, height: y + rowHeight))
    }
}
