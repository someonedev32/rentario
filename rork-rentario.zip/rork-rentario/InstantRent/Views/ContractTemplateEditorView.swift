import SwiftUI
import SwiftData

struct ContractTemplateEditorView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    var template: ContractTemplate?

    @State private var name: String = ""
    @State private var content: String = ""
    @State private var showResetConfirmation: Bool = false

    private let variables = [
        ("{{date}}", "Current Date"),
        ("{{client_name}}", "Client Name"),
        ("{{client_phone}}", "Client Phone"),
        ("{{client_email}}", "Client Email"),
        ("{{car_make}}", "Car Make"),
        ("{{car_model}}", "Car Model"),
        ("{{car_year}}", "Car Year"),
        ("{{car_license_plate}}", "License Plate"),
        ("{{car_color}}", "Car Color"),
        ("{{car_transmission}}", "Transmission"),
        ("{{car_fuel_type}}", "Fuel Type"),
        ("{{km_at_pickup}}", "KM at Pickup"),
        ("{{pickup_date}}", "Pickup Date"),
        ("{{return_date}}", "Return Date"),
        ("{{number_of_days}}", "Number of Days"),
        ("{{daily_rate}}", "Daily Rate"),
        ("{{extras_list}}", "Extras List"),
        ("{{discount}}", "Discount"),
        ("{{total_price}}", "Total Price"),
    ]

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Form {
                    Section(L10n.templateName) {
                        TextField(L10n.templateName, text: $name)
                    }

                    Section(L10n.insertVariable) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(variables, id: \.0) { variable, label in
                                    Button(action: { content += variable }) {
                                        Text(label)
                                            .font(.caption2)
                                            .padding(.horizontal, 10)
                                            .padding(.vertical, 6)
                                            .background(Color.orange.opacity(0.12))
                                            .foregroundStyle(.orange)
                                            .clipShape(.capsule)
                                    }
                                }
                            }
                        }
                    }

                    Section {
                        TextEditor(text: $content)
                            .font(.system(.caption, design: .monospaced))
                            .frame(minHeight: 300)
                    } header: {
                        HStack {
                            Text(L10n.templateContent)
                            Spacer()
                            Button {
                                showResetConfirmation = true
                            } label: {
                                Label(L10n.restoreDefault, systemImage: "arrow.counterclockwise")
                                    .font(.caption2)
                                    .foregroundStyle(.orange)
                            }
                        }
                    }
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle(L10n.editTemplate)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.cancel) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(L10n.save) { saveTemplate() }
                        .disabled(name.isEmpty || content.isEmpty)
                        .fontWeight(.semibold)
                }
            }
            .onAppear { loadTemplate() }
            .confirmationDialog(L10n.restoreDefaultConfirm, isPresented: $showResetConfirmation, titleVisibility: .visible) {
                Button(L10n.restoreDefault, role: .destructive) {
                    content = ContractTemplate.defaultContent
                }
                Button(L10n.cancel, role: .cancel) {}
            } message: {
                Text(L10n.restoreDefaultMessage)
            }
        }
    }

    private func loadTemplate() {
        if let template {
            name = template.name
            content = template.content
        } else {
            name = L10n.createDefaultTemplate
            content = ContractTemplate.defaultContent
        }
    }

    private func saveTemplate() {
        if let template {
            template.name = name
            template.content = content
        } else {
            let newTemplate = ContractTemplate(name: name, content: content, isDefault: true)
            modelContext.insert(newTemplate)
        }
        dismiss()
    }
}
