import SwiftUI
import SwiftData
import PhotosUI

struct AddEditClientView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    var client: Client?

    @State private var fullName: String = ""
    @State private var phone: String = ""
    @State private var email: String = ""
    @State private var notes: String = ""
    @State private var idFrontPath: String?
    @State private var idBackPath: String?
    @State private var licenseFrontPath: String?
    @State private var licenseBackPath: String?

    @State private var selectedIDFrontItem: PhotosPickerItem?
    @State private var selectedIDBackItem: PhotosPickerItem?
    @State private var selectedLicenseFrontItem: PhotosPickerItem?
    @State private var selectedLicenseBackItem: PhotosPickerItem?

    private var isEditing: Bool { client != nil }

    var body: some View {
        NavigationStack {
            Form {
                Section(L10n.generalInfo) {
                    TextField(L10n.fullName, text: $fullName)
                        .textContentType(.name)
                    TextField(L10n.phone, text: $phone)
                        .keyboardType(.phonePad)
                        .textContentType(.telephoneNumber)
                    TextField(L10n.email, text: $email)
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                }

                Section(L10n.notes) {
                    TextEditor(text: $notes)
                        .frame(minHeight: 80)
                }

                Section(L10n.idDocuments) {
                    HStack(spacing: 12) {
                        DocumentSlot(
                            label: L10n.front,
                            path: idFrontPath,
                            pickerItem: $selectedIDFrontItem,
                            onDelete: {
                                if let p = idFrontPath {
                                    ImageStorageService.deleteImage(relativePath: p)
                                    idFrontPath = nil
                                }
                            }
                        )
                        DocumentSlot(
                            label: L10n.back,
                            path: idBackPath,
                            pickerItem: $selectedIDBackItem,
                            onDelete: {
                                if let p = idBackPath {
                                    ImageStorageService.deleteImage(relativePath: p)
                                    idBackPath = nil
                                }
                            }
                        )
                    }
                    .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
                }
                .onChange(of: selectedIDFrontItem) { _, newItem in
                    handlePhotoPick(newItem, folder: "id_documents") { path in
                        if let old = idFrontPath { ImageStorageService.deleteImage(relativePath: old) }
                        idFrontPath = path
                        selectedIDFrontItem = nil
                    }
                }
                .onChange(of: selectedIDBackItem) { _, newItem in
                    handlePhotoPick(newItem, folder: "id_documents") { path in
                        if let old = idBackPath { ImageStorageService.deleteImage(relativePath: old) }
                        idBackPath = path
                        selectedIDBackItem = nil
                    }
                }

                Section(L10n.driverLicense) {
                    HStack(spacing: 12) {
                        DocumentSlot(
                            label: L10n.front,
                            path: licenseFrontPath,
                            pickerItem: $selectedLicenseFrontItem,
                            onDelete: {
                                if let p = licenseFrontPath {
                                    ImageStorageService.deleteImage(relativePath: p)
                                    licenseFrontPath = nil
                                }
                            }
                        )
                        DocumentSlot(
                            label: L10n.back,
                            path: licenseBackPath,
                            pickerItem: $selectedLicenseBackItem,
                            onDelete: {
                                if let p = licenseBackPath {
                                    ImageStorageService.deleteImage(relativePath: p)
                                    licenseBackPath = nil
                                }
                            }
                        )
                    }
                    .listRowInsets(EdgeInsets(top: 12, leading: 16, bottom: 12, trailing: 16))
                }
                .onChange(of: selectedLicenseFrontItem) { _, newItem in
                    handlePhotoPick(newItem, folder: "driver_licenses") { path in
                        if let old = licenseFrontPath { ImageStorageService.deleteImage(relativePath: old) }
                        licenseFrontPath = path
                        selectedLicenseFrontItem = nil
                    }
                }
                .onChange(of: selectedLicenseBackItem) { _, newItem in
                    handlePhotoPick(newItem, folder: "driver_licenses") { path in
                        if let old = licenseBackPath { ImageStorageService.deleteImage(relativePath: old) }
                        licenseBackPath = path
                        selectedLicenseBackItem = nil
                    }
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle(isEditing ? L10n.editClient : L10n.addClient)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.cancel) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(L10n.save) { saveClient() }
                        .disabled(fullName.trimmingCharacters(in: .whitespaces).isEmpty)
                        .fontWeight(.semibold)
                }
            }
            .onAppear { loadClientData() }
        }
    }

    private func handlePhotoPick(_ item: PhotosPickerItem?, folder: String, completion: @escaping (String) -> Void) {
        guard let item else { return }
        Task {
            if let data = try? await item.loadTransferable(type: Data.self),
               let image = UIImage(data: data),
               let path = ImageStorageService.saveImage(image, folder: folder) {
                completion(path)
            }
        }
    }

    private func loadClientData() {
        guard let client else { return }
        fullName = client.fullName
        phone = client.phone
        email = client.email
        notes = client.notes
        idFrontPath = client.idFrontPath
        idBackPath = client.idBackPath
        licenseFrontPath = client.licenseFrontPath
        licenseBackPath = client.licenseBackPath
    }

    private func saveClient() {
        if let client {
            client.fullName = fullName
            client.phone = phone
            client.email = email
            client.notes = notes
            client.idFrontPath = idFrontPath
            client.idBackPath = idBackPath
            client.licenseFrontPath = licenseFrontPath
            client.licenseBackPath = licenseBackPath
        } else {
            let newClient = Client(
                fullName: fullName,
                phone: phone,
                email: email,
                notes: notes,
                idFrontPath: idFrontPath,
                idBackPath: idBackPath,
                licenseFrontPath: licenseFrontPath,
                licenseBackPath: licenseBackPath
            )
            modelContext.insert(newClient)
        }
        dismiss()
    }
}

struct DocumentSlot: View {
    let label: String
    let path: String?
    @Binding var pickerItem: PhotosPickerItem?
    let onDelete: () -> Void

    @State private var image: UIImage?

    var body: some View {
        VStack(spacing: 6) {
            Text(label)
                .font(.caption.weight(.medium))
                .foregroundStyle(.secondary)

            if let image {
                Color(.secondarySystemBackground)
                    .frame(height: 90)
                    .overlay {
                        Image(uiImage: image)
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .allowsHitTesting(false)
                    }
                    .clipShape(.rect(cornerRadius: 10))
                    .overlay(alignment: .topTrailing) {
                        Button(action: {
                            onDelete()
                            self.image = nil
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.body)
                                .foregroundStyle(.white, .red)
                        }
                        .offset(x: 6, y: -6)
                    }
            } else {
                PhotosPicker(selection: $pickerItem, matching: .images) {
                    VStack(spacing: 8) {
                        Image(systemName: "camera.fill")
                            .font(.title3)
                            .foregroundStyle(.orange)
                        Text(L10n.addPhoto)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .frame(height: 90)
                    .frame(maxWidth: .infinity)
                    .background(Color(.tertiarySystemFill))
                    .clipShape(.rect(cornerRadius: 10))
                }
                .buttonStyle(.plain)
            }
        }
        .frame(maxWidth: .infinity)
        .onAppear {
            if let path {
                image = ImageStorageService.loadImage(relativePath: path)
            }
        }
        .onChange(of: path) { _, newPath in
            if let newPath {
                image = ImageStorageService.loadImage(relativePath: newPath)
            } else {
                image = nil
            }
        }
    }
}
