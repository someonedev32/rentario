import SwiftUI
import SwiftData

struct RentalsListView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Rental.createdAt, order: .reverse) private var rentals: [Rental]
    @State private var selectedStatus: RentalStatus? = nil
    @State private var searchText: String = ""
    @State private var rentalToDelete: Rental? = nil

    private var filteredRentals: [Rental] {
        var result = rentals
        if let status = selectedStatus {
            result = result.filter { $0.status == status }
        }
        if !searchText.isEmpty {
            result = result.filter {
                $0.car?.displayName.localizedStandardContains(searchText) == true ||
                $0.client?.fullName.localizedStandardContains(searchText) == true
            }
        }
        return result
    }

    var body: some View {
        VStack(spacing: 0) {
            statusFilterBar
            rentalsList
        }
        .background(Color.appBackground)
        .navigationTitle(L10n.rentals)
        .searchable(text: $searchText, prompt: Text(L10n.search))
        .alert(L10n.delete, isPresented: Binding(get: { rentalToDelete != nil }, set: { if !$0 { rentalToDelete = nil } })) {
            Button(L10n.cancel, role: .cancel) { rentalToDelete = nil }
            Button(L10n.delete, role: .destructive) { performDelete() }
        } message: {
            Text(L10n.deleteConfirmation)
        }
    }

    private var statusFilterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                FilterChip(title: L10n.allStatuses, isSelected: selectedStatus == nil) {
                    selectedStatus = nil
                }
                ForEach(RentalStatus.allCases, id: \.self) { status in
                    FilterChip(title: status.displayName, isSelected: selectedStatus == status, color: status.color) {
                        selectedStatus = status
                    }
                }
            }
            .padding(.vertical, 8)
        }
        .contentMargins(.horizontal, 16)
    }

    private var rentalsList: some View {
        List {
            ForEach(filteredRentals) { rental in
                NavigationLink(destination: RentalDetailView(rental: rental)) {
                    RentalListRow(rental: rental)
                }
                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                    Button(role: .destructive) {
                        rentalToDelete = rental
                    } label: {
                        Label(L10n.delete, systemImage: "trash")
                    }
                }
            }
        }
        .listStyle(.plain)
        .overlay {
            if filteredRentals.isEmpty {
                ContentUnavailableView(L10n.noRentals, systemImage: "doc.text.fill")
            }
        }
    }

    private func performDelete() {
        guard let rental = rentalToDelete else { return }
        if rental.status == .active {
            rental.car?.status = .free
        }
        modelContext.delete(rental)
        try? modelContext.save()
        rentalToDelete = nil
    }
}

struct RentalListRow: View {
    @Environment(CurrencyManager.self) private var currencyManager
    let rental: Rental

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: rental.status.icon)
                .font(.title3)
                .foregroundStyle(rental.status.color)
                .frame(width: 40, height: 40)
                .background(rental.status.color.opacity(0.12))
                .clipShape(.rect(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 4) {
                Text(rental.car?.displayName ?? "-")
                    .font(.subheadline.weight(.semibold))
                Text(rental.client?.fullName ?? "-")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 4) {
                Text(rental.totalPrice, format: .currency(code: currencyManager.currencyCode))
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.orange)
                Text(rental.pickupDate, style: .date)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
    }
}
