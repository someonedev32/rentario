import SwiftUI

struct ContentView: View {
    @Environment(SubscriptionService.self) private var subscriptionService
    @State private var hasCheckedEntitlement: Bool = false
    @State private var paywallDismissed: Bool = false

    var body: some View {
        Group {
            if !hasCheckedEntitlement {
                LaunchLoadingView()
            } else if subscriptionService.isProUser || paywallDismissed {
                MainTabView()
            } else {
                PaywallView(onDismiss: { paywallDismissed = true })
            }
        }
        .task {
            await subscriptionService.checkEntitlement()
            hasCheckedEntitlement = true
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            Task {
                await subscriptionService.checkEntitlement()
            }
        }
    }
}

struct LaunchLoadingView: View {
    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            VStack(spacing: 16) {
                Image("AppIconImage")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 72, height: 72)
                    .clipShape(.rect(cornerRadius: 16))
                Text("Rentario")
                    .font(.title.bold())
                ProgressView()
                    .tint(.orange)
            }
        }
    }
}
