import Foundation
import SwiftData

nonisolated enum CarStatus: String, Codable, CaseIterable, Sendable {
    case free
    case rented
    case maintenance
}

nonisolated enum TransmissionType: String, Codable, CaseIterable, Sendable {
    case manual
    case automatic
}

nonisolated enum FuelType: String, Codable, CaseIterable, Sendable {
    case gasoline
    case diesel
    case electric
    case hybrid
    case lpg
}

nonisolated enum CarColor: String, Codable, CaseIterable, Sendable {
    case black
    case white
    case silver
    case gray
    case red
    case blue
    case darkBlue
    case green
    case brown
    case beige
    case orange
    case yellow
    case burgundy
}

@Model
class Car {
    var id: UUID
    var make: String
    var model: String
    var year: Int
    var licensePlate: String
    var color: String
    var photoURL: String
    @Attribute(.externalStorage) var imageData: Data?
    var statusRaw: String
    var odometer: Int
    var transmissionRaw: String
    var fuelTypeRaw: String
    var doors: Int
    var seats: Int
    var colorRaw: String
    var features: [String]
    var dailyRate: Double
    var lastMaintenanceDate: Date?
    var insuranceExpiryDate: Date?
    var createdAt: Date
    @Relationship(deleteRule: .nullify, inverse: \Rental.car) var rentals: [Rental]

    var status: CarStatus {
        get { CarStatus(rawValue: statusRaw) ?? .free }
        set { statusRaw = newValue.rawValue }
    }

    var transmission: TransmissionType {
        get { TransmissionType(rawValue: transmissionRaw) ?? .manual }
        set { transmissionRaw = newValue.rawValue }
    }

    var fuelType: FuelType {
        get { FuelType(rawValue: fuelTypeRaw) ?? .gasoline }
        set { fuelTypeRaw = newValue.rawValue }
    }

    var carColor: CarColor {
        get { CarColor(rawValue: colorRaw) ?? .black }
        set { colorRaw = newValue.rawValue }
    }

    var displayName: String { "\(make) \(model)" }

    var isInsuranceExpiringSoon: Bool {
        guard let expiryDate = insuranceExpiryDate else { return false }
        let oneWeekFromNow = Calendar.current.date(byAdding: .day, value: 7, to: Date()) ?? Date()
        return expiryDate <= oneWeekFromNow && expiryDate >= Date().startOfDay
    }

    var isInsuranceExpired: Bool {
        guard let expiryDate = insuranceExpiryDate else { return false }
        return expiryDate < Date().startOfDay
    }

    init(
        make: String = "",
        model: String = "",
        year: Int = Calendar.current.component(.year, from: Date()),
        licensePlate: String = "",
        color: String = "",
        photoURL: String = "",
        imageData: Data? = nil,
        status: CarStatus = .free,
        odometer: Int = 0,
        transmission: TransmissionType = .manual,
        fuelType: FuelType = .gasoline,
        carColor: CarColor = .black,
        doors: Int = 4,
        seats: Int = 5,
        features: [String] = [],
        dailyRate: Double = 0,
        lastMaintenanceDate: Date? = nil,
        insuranceExpiryDate: Date? = nil
    ) {
        self.id = UUID()
        self.make = make
        self.model = model
        self.year = year
        self.licensePlate = licensePlate
        self.color = color
        self.photoURL = photoURL
        self.imageData = imageData
        self.statusRaw = status.rawValue
        self.odometer = odometer
        self.transmissionRaw = transmission.rawValue
        self.fuelTypeRaw = fuelType.rawValue
        self.colorRaw = carColor.rawValue
        self.doors = doors
        self.seats = seats
        self.features = features
        self.dailyRate = dailyRate
        self.lastMaintenanceDate = lastMaintenanceDate
        self.insuranceExpiryDate = insuranceExpiryDate
        self.createdAt = Date()
        self.rentals = []
    }
}
