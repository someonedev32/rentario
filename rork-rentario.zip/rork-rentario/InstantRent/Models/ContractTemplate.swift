import Foundation
import SwiftData

@Model
class ContractTemplate {
    var id: UUID
    var name: String
    var content: String
    var isDefault: Bool
    var createdAt: Date

    static let defaultContent: String = """
    RENTAL AGREEMENT

    Date: {{date}}

    RENTER INFORMATION
    Name: {{client_name}}
    Phone: {{client_phone}}
    Email: {{client_email}}

    VEHICLE INFORMATION
    Vehicle: {{car_make}} {{car_model}} ({{car_year}})
    License Plate: {{car_license_plate}}
    Color: {{car_color}}
    Transmission: {{car_transmission}}
    Fuel Type: {{car_fuel_type}}
    Odometer at Pickup: {{km_at_pickup}} km

    RENTAL DETAILS
    Pickup Date: {{pickup_date}}
    Return Date: {{return_date}}
    Number of Days: {{number_of_days}}
    Daily Rate: {{daily_rate}}
    Extras: {{extras_list}}
    Discount: {{discount}}
    Total Price: {{total_price}}

    TERMS AND CONDITIONS
    1. The renter agrees to return the vehicle in the same condition as received.
    2. The renter is responsible for all traffic violations during the rental period.
    3. Fuel must be returned at the same level as at pickup.
    4. Any damage must be reported immediately.

    SIGNATURES

    Renter Signature: ___________________________

    Date: {{date}}
    """

    init(
        name: String = "Default Template",
        content: String = ContractTemplate.defaultContent,
        isDefault: Bool = true
    ) {
        self.id = UUID()
        self.name = name
        self.content = content
        self.isDefault = isDefault
        self.createdAt = Date()
    }
}
