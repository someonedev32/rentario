import Foundation

nonisolated struct RentalExtra: Codable, Identifiable, Hashable, Sendable {
    var id: UUID
    var name: String
    var pricePerDay: Double
    var isFlat: Bool

    init(id: UUID = UUID(), name: String = "", pricePerDay: Double = 0, isFlat: Bool = false) {
        self.id = id
        self.name = name
        self.pricePerDay = pricePerDay
        self.isFlat = isFlat
    }
}
