import Foundation
import SwiftData

@Model
class Client {
    var id: UUID
    var fullName: String
    var phone: String
    var email: String
    var notes: String
    var idFrontPath: String?
    var idBackPath: String?
    var licenseFrontPath: String?
    var licenseBackPath: String?
    var createdAt: Date
    @Relationship(deleteRule: .nullify, inverse: \Rental.client) var rentals: [Rental]

    init(
        fullName: String = "",
        phone: String = "",
        email: String = "",
        notes: String = "",
        idFrontPath: String? = nil,
        idBackPath: String? = nil,
        licenseFrontPath: String? = nil,
        licenseBackPath: String? = nil
    ) {
        self.id = UUID()
        self.fullName = fullName
        self.phone = phone
        self.email = email
        self.notes = notes
        self.idFrontPath = idFrontPath
        self.idBackPath = idBackPath
        self.licenseFrontPath = licenseFrontPath
        self.licenseBackPath = licenseBackPath
        self.createdAt = Date()
        self.rentals = []
    }
}
