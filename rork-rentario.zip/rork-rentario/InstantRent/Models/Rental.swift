import Foundation
import SwiftData

nonisolated enum RentalStatus: String, Codable, CaseIterable, Sendable {
    case active
    case completed
    case cancelled
}

@Model
class Rental {
    var id: UUID
    var car: Car?
    var client: Client?
    var pickupDate: Date
    var returnDate: Date
    var actualReturnDate: Date?
    var statusRaw: String
    var kmAtPickup: Int
    var kmAtReturn: Int?
    var dailyRate: Double
    var extras: [RentalExtra]
    var discountType: String
    var discountValue: Double
    var totalPrice: Double
    var notes: String
    var pickupLocation: String
    var dropoffLocation: String
    var signatureImagePath: String?
    var contractPDFPath: String?
    var createdAt: Date

    var status: RentalStatus {
        get { RentalStatus(rawValue: statusRaw) ?? .active }
        set { statusRaw = newValue.rawValue }
    }

    var numberOfDays: Int {
        let endDate = actualReturnDate ?? returnDate
        let days = Calendar.current.dateComponents([.day], from: pickupDate, to: endDate).day ?? 1
        return max(days, 1)
    }

    init(
        car: Car? = nil,
        client: Client? = nil,
        pickupDate: Date = Date(),
        returnDate: Date = Date().addingTimeInterval(86400),
        status: RentalStatus = .active,
        kmAtPickup: Int = 0,
        dailyRate: Double = 0,
        extras: [RentalExtra] = [],
        discountType: String = "none",
        discountValue: Double = 0,
        totalPrice: Double = 0,
        notes: String = "",
        pickupLocation: String = "",
        dropoffLocation: String = ""
    ) {
        self.id = UUID()
        self.car = car
        self.client = client
        self.pickupDate = pickupDate
        self.returnDate = returnDate
        self.statusRaw = status.rawValue
        self.kmAtPickup = kmAtPickup
        self.dailyRate = dailyRate
        self.extras = extras
        self.discountType = discountType
        self.discountValue = discountValue
        self.totalPrice = totalPrice
        self.notes = notes
        self.pickupLocation = pickupLocation
        self.dropoffLocation = dropoffLocation
        self.createdAt = Date()
    }
}
