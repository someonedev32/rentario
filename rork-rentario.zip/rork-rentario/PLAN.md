# Rentario — Car Rental Management App

## Overview
A professional offline-first car rental management app for local businesses. Orange accent color, follows system light/dark mode, fully localized in English and German.

---

## **Features**

### Dashboard
- At-a-glance summary: active rentals today, cars available, upcoming returns
- Quick-action buttons to create a new rental, add a car, or add a client
- Revenue summary for the current week/month

### Car Management
- Add, edit, and delete cars with: make, model, year, license plate, color, photo URL
- Track: status (free / rented / maintenance), odometer, transmission type, fuel type, doors, seats
- Add car features (e.g. GPS, child seat, Bluetooth)
- View full rental history per car
- Filter cars by status

### Client Management
- Add, edit, and delete clients with: full name, phone number, email, notes
- Capture and store ID document photos and driver license photos locally on the device
- View full rental history per client

### Reservation Management
- Create a new rental by selecting a car, a client, pickup/return dates, and extras
- Automatic price calculation based on daily rate, number of days, extras, and discounts
- Track KM at handover (pickup odometer) and KM at return
- Edit active rentals and close completed ones
- Rental statuses: active, completed, cancelled

### Calendar
- Daily view showing all rentals for a selected day
- Weekly view showing a week-at-a-glance grid of car availability
- Tap any rental to jump to its detail

### Contract System
- Editable contract template with dynamic variables (client name, car details, dates, KM, price, etc.)
- Vehicle details, transmission, fuel type, and KM at handover automatically inserted
- Digital signature pad for the client to sign on-screen
- Generate a polished PDF from the signed contract
- Share the PDF via the iOS share sheet or print it directly

### Pricing Engine
- Set daily rental rates per car
- Add extras (GPS, insurance, child seat, etc.) with per-day or flat pricing
- Apply percentage or fixed-amount discounts
- Automatic total calculation shown in real time

### Localization
- All UI text localized in English and German
- User can switch language in Settings
- Contracts default to English; language can be changed per contract

### Subscription & Paywall
- Paywall appears on first launch, blocking access until subscribed or trial started
- Two packages: Monthly and Yearly — both with a 7-day free trial
- Full unlimited access during the trial
- Restore purchases button on the paywall
- Subscription status cached locally so entitlement works offline after validation
- Powered by RevenueCat SDK with centralized EntitlementManager
- Three subscription states: active, expired, inactive — reflected in Paywall and Settings
- Feature gating on add rental, add car, add client — non-Pro users see the paywall
- Automatic downgrade when subscription expires/is revoked via RevenueCat delegate
- Entitlements refreshed on app launch, foreground return, purchase, restore, and RevenueCat customer info updates

---

## **Design**

- Orange accent color throughout for brand identity — buttons, highlights, and active states
- System light/dark mode support with semantic colors
- Clean card-based layouts for car and client lists
- Status badges with color coding: green (free), orange (rented), red (maintenance)
- Smooth spring animations on transitions and interactions
- Haptic feedback on key actions (creating rentals, signing contracts)
- Native iOS feel: large navigation titles on root screens, inline on detail screens
- Tab bar with 5 tabs: Dashboard, Calendar, Cars, Clients, Settings
- SF Symbols used for all icons

---

## **Screens**

1. **Paywall** — Full-screen with app branding, feature highlights, Monthly/Yearly options, restore purchases, and start trial button
2. **Dashboard** — Summary cards, quick actions, today's rentals preview
3. **Calendar** — Segmented control for daily/weekly view, color-coded rental blocks
4. **Cars List** — Searchable list with status filters, car thumbnails, and status badges
5. **Car Detail** — Full car info, current status, rental history, edit button
6. **Add/Edit Car** — Form with all car fields, feature picker
7. **Clients List** — Searchable list with client names and phone numbers
8. **Client Detail** — Client info, document photos, rental history
9. **Add/Edit Client** — Form with photo capture for ID and license
10. **Rentals List** — Accessible from Dashboard; filterable by status
11. **New Rental** — Step-by-step: select car → select client → set dates & extras → review pricing → confirm
12. **Rental Detail** — Full rental info, pricing breakdown, KM tracking, contract actions
13. **Contract Template Editor** — Rich text editor with variable insertion buttons
14. **Contract Signing** — Contract preview with signature pad at the bottom
15. **PDF Preview** — Generated contract PDF with share and print buttons
16. **Settings** — Language toggle, currency display, contract template management, about/support info

---

## **Data & Offline**
- All data stored locally on-device using SwiftData
- Photos and documents stored via FileManager in the app's documents directory
- PDFs generated and saved locally
- Signature images stored locally
- No internet required for any core business feature
- Subscription entitlement state cached in UserDefaults for offline access after initial RevenueCat validation

---

## **App Icon**
- Orange gradient background (warm amber to vibrant orange)
- White car key silhouette icon in the center
- Clean, modern, and recognizable at small sizes
