# Rentario — Paywall & Subscription Audit

## SDK & Provider
- **RevenueCat** (Swift SDK)
- Configured in `InstantRentApp.swift` at app launch

## API Keys (Config.swift)
| Key | Usage |
|-----|-------|
| `EXPO_PUBLIC_REVENUECAT_TEST_API_KEY` | Used in **DEBUG** builds (`test_ekiKvUWMUTebOZhJGrrdnrvLQSx`) |
| `EXPO_PUBLIC_REVENUECAT_IOS_API_KEY` | Used in **RELEASE** builds (`appl_TRmnHylaBCLxoaDzGjsZOajZjCy`) |

Debug builds also enable `Purchases.logLevel = .debug`.

---

## RevenueCat Configuration

### Entitlement
- **Entitlement ID:** `"pro"`
- Checked via `customerInfo.entitlements["pro"]?.isActive`

### Offerings
- Uses `Purchases.shared.offerings()` → `offerings.current`
- Packages are fetched from the **current offering** configured in the RevenueCat dashboard
- Packages are sorted by duration descending (yearly first, monthly second)
- Fetching retries up to **3 attempts** with exponential backoff (1s, 2s delays)

### Expected Products (configured in RevenueCat dashboard)
- **Yearly** subscription package
- **Monthly** subscription package
- Both should have a **7-day free trial** (introductory offer) configured in App Store Connect

---

## Subscription States

Three states managed by `EntitlementManager`:

| State | Condition | Paywall Behavior | Settings Behavior |
|-------|-----------|------------------|-------------------|
| **active** | `entitlements["pro"]?.isActive == true` | Shows "Pro Active" + "Go to App" button | Shows green checkmark, "Change or Cancel Plan" (opens Apple manage subscriptions sheet) |
| **expired** | Entitlement exists but `isActive == false` | Shows expired warning + resubscribe flow with packages | Shows orange warning, "Resubscribe" button opens paywall |
| **inactive** | No entitlement record at all | Shows full paywall with features + packages | Shows "Upgrade to Pro" button opens paywall |

---

## Architecture

### Files
| File | Role |
|------|------|
| `InstantRentApp.swift` | Configures RevenueCat SDK, creates `SubscriptionService`, injects into environment |
| `EntitlementManager.swift` | Singleton. Tracks `ProState`, caches state in UserDefaults, listens to RevenueCat delegate |
| `SubscriptionService.swift` | `@Observable` service. Fetches offerings, handles purchases/restores, exposes packages and pro state to UI |
| `PaywallView.swift` | Full paywall UI with branding, features list, package selection, purchase CTA |
| `ContentView.swift` | App entry point — gates access behind paywall unless pro or dismissed |
| `SettingsView.swift` | Shows subscription status, manage/cancel, restore, redeem code |

### Data Flow
```
InstantRentApp
  └─ Purchases.configure(withAPIKey:)
  └─ SubscriptionService (injected as @Environment)
       └─ EntitlementManager.shared (singleton)
            └─ PurchaseDelegateHandler (RevenueCat delegate, updates entitlements on changes)
```

### Entitlement Refresh Points
1. **App launch** — `ContentView.task` calls `subscriptionService.checkEntitlement()`
2. **App returns to foreground** — `willEnterForegroundNotification` triggers refresh
3. **After purchase** — `purchase()` updates from `result.customerInfo`
4. **After restore** — `restorePurchases()` updates from restored `customerInfo`
5. **RevenueCat delegate** — `PurchaseDelegateHandler.purchases(_:receivedUpdated:)` fires on any server-side change (renewal, cancellation, billing issue)

### Offline Support
- Pro state cached in `UserDefaults` (key: `"cached_pro_state"`)
- On cold launch with no network, the cached state is used
- Refreshed whenever network is available

---

## Paywall UI Behavior

### Launch Gate
- `ContentView` checks entitlement on appear
- Shows `LaunchLoadingView` (app icon + spinner) while checking
- If **not pro**: shows `PaywallView` with an `onDismiss` callback
- User can dismiss paywall without subscribing → enters app (no hard gate)
- On next foreground return, entitlement is re-checked

### Package Selection
- Auto-selects the **yearly** package by default
- Each package card shows:
  - Product title (from App Store Connect)
  - Period (e.g., "per year", "per month")
  - Localized price
  - Savings percentage badge (calculated vs shortest package's monthly rate)
  - "Best Value" banner on the longest package
- Radio-button style selection with orange highlight

### CTA Button
- Dynamically shows trial duration if introductory offer exists (e.g., "Start 1 Week Free Trial")
- Falls back to "Start Free Trial" or "Resubscribe" depending on state
- Shows spinner during purchase

### Footer
- Dynamic trial info text listing all package prices
- Links to: Privacy Policy, Terms of Use (Apple EULA)
- Restore Purchases button

---

## Settings Subscription Section

### Active State
- Green checkmark seal icon
- "Change or Cancel Plan" — opens `AppStore.showManageSubscriptions(in:)` (native Apple sheet where user can upgrade from 6-month to 12-month, downgrade, or cancel)
- "Restore Purchases" button
- "Redeem Code" — opens `AppStore.presentOfferCodeRedeemSheet(in:)`

### Expired State
- Orange warning triangle icon
- "Resubscribe" button opens paywall sheet
- "Redeem Code" button

### Inactive State
- Orange crown icon with "Upgrade to Pro"
- Opens paywall sheet
- "Redeem Code" button

---

## Savings Calculation Logic
- Compares each package's effective monthly price against the shortest package's monthly price
- Formula: `((shortMonthlyPrice - pkgMonthlyPrice) / shortMonthlyPrice) * 100`
- Only shown if savings > 0% and package is longer than shortest

---

## Legal Links
| Link | URL |
|------|-----|
| Privacy Policy | `https://sites.google.com/view/renatrio/home` |
| Terms of Use | `https://www.apple.com/legal/internet-services/itunes/dev/stdeula/` (Apple Standard EULA) |

---

## Checklist for RevenueCat Dashboard

- [ ] Entitlement `"pro"` exists
- [ ] Current offering is set with monthly + yearly packages
- [ ] Products are linked to App Store Connect subscription products
- [ ] 7-day free trial configured as introductory offer in App Store Connect
- [ ] API keys match Config.swift values
- [ ] Sandbox testing verified with test accounts
