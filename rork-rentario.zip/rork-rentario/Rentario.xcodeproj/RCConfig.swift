// RCConfig.swift
// Tracks RevenueCat configuration state.

import Foundation

enum RCConfig {
    // Set to true immediately after Purchases.configure(...)
    static var isConfigured: Bool = false
}
